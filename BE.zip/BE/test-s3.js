// test-s3.js
const AWS = require('aws-sdk');

AWS.config.update({
    accessKeyId: 'AKIAYWDI2CNZX4QP7WE4',
    secretAccessKey: '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',
    region: 'us-east-1'
});

const s3 = new AWS.S3();

s3.listBuckets((err, data) => {
    if (err) {
        console.log("Error:", err);
    } else {
        console.log("Buckets:", data.Buckets);
    }
});
