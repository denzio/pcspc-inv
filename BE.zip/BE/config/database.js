const { Sequelize } = require("sequelize");

const sequelize = new Sequelize({
  dialect: "mysql", // Change dialect to 'mysql'
  host: "database-1.c1ymq60io07n.us-east-1.rds.amazonaws.com", // MySQL server host (assuming it's running on localhost)
  port: 3306, // Default MySQL port
  username: "admin", // Your MySQL username
  password: "L3tm31n123!", // Your MySQL password
  database: "duwltnjc_dbdev", // Name of your MySQL database
});

module.exports = { sequelize };
