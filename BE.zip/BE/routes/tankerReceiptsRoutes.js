const express = require("express");
const router = express.Router();
const { sequelize } = require("../models"); // Adjust the path accordingly
const { TankerReceipts } = require("../models");

// POST API to create a new tanker receipt
router.post("/saveVesselTankBunkering", async (req, res) => {
  const {
    TRID,
    SessionID,
    TankID,
    CalibType,
    ProductID,
    Transaction,
    GTicketNum,
    ClientNames,
    Volumes,
    TotalVolume,
    VesselName,
    VONumber,
    OpeningDateTime,
    ClosingDateTime,
    RegaugeDateTime,
    OpeningProductFT,
    ClosingProductFT,
    RegaugeProductFT,
    OpeningProductInch,
    ClosingProductInch,
    RegaugeProductInch,
    OpeningProduct16,
    ClosingProduct16,
    RegaugeProduct16,
    OpeningWaterFT,
    ClosingWaterFT,
    RegaugeWaterFT,
    OpeningWaterInch,
    ClosingWaterInch,
    RegaugeWaterInch,
    OpeningWater16,
    ClosingWater16,
    RegaugeWater16,
    OpeningProductMetric,
    ClosingProductMetric,
    RegaugeProductMetric,
    OpeningWaterMetric,
    ClosingWaterMetric,
    RegaugeWaterMetric,
    OpeningTemperature,
    ClosingTemperature,
    RegaugeTemperature,
    OpeningDensity15oC,
    ClosingDensity15oC,
    RegaugeDensity15oC,
    Status,
    Remarks,
    Attachments,
    WithDenaturing,
    VolumeAtAir,
    VolumeAt60,
    SubmitCount,
    Submitted,
  } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_SaveVesselTankBunkering(:TRID, :SessionID, :CalibType, :TankID, :ProductID, :Transaction, :GTicketNum, :ClientNames, :Volumes, :TotalVolume, :VesselName, :VONumber, :OpeningDateTime, :ClosingDateTime,:RegaugeDateTime, :OpeningProductFT, :ClosingProductFT, :RegaugeProductFT, :OpeningProductInch, :ClosingProductInch, :RegaugeProductInch, :OpeningProduct16, :ClosingProduct16,:RegaugeProduct16, :OpeningWaterFT, :ClosingWaterFT, :RegaugeWaterFT, :OpeningWaterInch, :ClosingWaterInch, :RegaugeWaterInch, :OpeningWater16, :ClosingWater16, :RegaugeWater16, :OpeningProductMetric, :ClosingProductMetric, :RegaugeProductMetric, :OpeningWaterMetric, :ClosingWaterMetric, :RegaugeWaterMetric, :OpeningTemperature, :ClosingTemperature, :RegaugeTemperature, :OpeningDensity15oC, :ClosingDensity15oC, :RegaugeDensity15oC, :Status, :Remarks, :Attachments, :WithDenaturing, :VolumeAtAir, :VolumeAt60, :SubmitCount, :Submitted)",
      {
        replacements: {
          TRID,
          SessionID,
          TankID,
          CalibType,
          ProductID,
          Transaction,
          GTicketNum,
          ClientNames,
          Volumes,
          TotalVolume,
          VesselName,
          VONumber,
          OpeningDateTime,
          ClosingDateTime,
          RegaugeDateTime,
          OpeningProductFT,
          ClosingProductFT,
          RegaugeProductFT,
          OpeningProductInch,
          ClosingProductInch,
          RegaugeProductInch,
          OpeningProduct16,
          ClosingProduct16,
          RegaugeProduct16,
          OpeningWaterFT,
          ClosingWaterFT,
          RegaugeWaterFT,
          OpeningWaterInch,
          ClosingWaterInch,
          RegaugeWaterInch,
          OpeningWater16,
          ClosingWater16,
          RegaugeWater16,
          OpeningProductMetric,
          ClosingProductMetric,
          RegaugeProductMetric,
          OpeningWaterMetric,
          ClosingWaterMetric,
          RegaugeWaterMetric,
          OpeningTemperature,
          ClosingTemperature,
          RegaugeTemperature,
          OpeningDensity15oC,
          ClosingDensity15oC,
          RegaugeDensity15oC,
          Status,
          Remarks,
          Attachments,
          WithDenaturing,
          VolumeAtAir,
          VolumeAt60,
          SubmitCount,
          Submitted,
        },
      }
    );

    return res.json(result);
  } catch (error) {
    console.error("Failed to create tanker receipt:", error);
    res.status(500).json({ error: "Failed to create tanker receipt" });
  }
});

router.post("/getVesselTankBunkeringRecord", async (req, res) => {
  const { SessionID, Transaction } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_GetVesselTankBunkeringRecord(:SessionID, :Transaction)",
      {
        replacements: {
          SessionID,
          Transaction,
        },
      }
    );
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetVesselTankBunkeringRecord:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/getTankerNextSessionID", async (req, res) => {
  try {
    const result = await sequelize.query("CALL SP_GetTankerNextSessionID()");
    res.json(result);
  } catch (error) {
    console.error("Error fetching getTankerNextSessionID:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
