const express = require("express");
const router = express.Router();
const { sequelize } = require("../models"); // Adjust the path accordingly
const { TankTruckIssuance } = require("../models");

router.post("/saveTankTruckIssuance", async (req, res) => {
  const {
    TRID,
    SessionID,
    TankID,
    CalibType,
    ProductID,
    Transaction,
    GTicketNum,
    ClientNames,
    Volumes,
    TotalVolume,
    OpeningDateTime,
    ClosingDateTime,
    RegaugeDateTime,
    OpeningProductFT,
    ClosingProductFT,
    RegaugeProductFT,
    OpeningProductInch,
    ClosingProductInch,
    RegaugeProductInch,
    OpeningProduct16,
    ClosingProduct16,
    RegaugeProduct16,
    OpeningWaterFT,
    ClosingWaterFT,
    RegaugeWaterFT,
    OpeningWaterInch,
    ClosingWaterInch,
    RegaugeWaterInch,
    OpeningWater16,
    ClosingWater16,
    RegaugeWater16,
    OpeningProductMetric,
    ClosingProductMetric,
    RegaugeProductMetric,
    OpeningWaterMetric,
    ClosingWaterMetric,
    RegaugeWaterMetric,
    OpeningTemperature,
    ClosingTemperature,
    RegaugeTemperature,
    OpeningDensity15oC,
    ClosingDensity15oC,
    RegaugeDensity15oC,
    Status,
    Remarks,
    Attachments,
    WithDenaturing,
    VolumeAtAir,
    VolumeAt60,
    SubmitCount,
    Submitted,
  } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_SaveTankTruckIssuance(:TRID, :SessionID, :CalibType, :TankID, :ProductID, :Transaction, :GTicketNum, :ClientNames, :Volumes, :TotalVolume, :OpeningDateTime, :ClosingDateTime,:RegaugeDateTime, :OpeningProductFT, :ClosingProductFT, :RegaugeProductFT, :OpeningProductInch, :ClosingProductInch, :RegaugeProductInch, :OpeningProduct16, :ClosingProduct16,:RegaugeProduct16, :OpeningWaterFT, :ClosingWaterFT, :RegaugeWaterFT, :OpeningWaterInch, :ClosingWaterInch, :RegaugeWaterInch, :OpeningWater16, :ClosingWater16, :RegaugeWater16, :OpeningProductMetric, :ClosingProductMetric, :RegaugeProductMetric, :OpeningWaterMetric, :ClosingWaterMetric, :RegaugeWaterMetric, :OpeningTemperature, :ClosingTemperature, :RegaugeTemperature, :OpeningDensity15oC, :ClosingDensity15oC, :RegaugeDensity15oC, :Status, :Remarks, :Attachments, :WithDenaturing, :VolumeAtAir, :VolumeAt60, :SubmitCount, :Submitted)",
      {
        replacements: {
          TRID,
          SessionID,
          TankID,
          CalibType,
          ProductID,
          Transaction,
          GTicketNum,
          ClientNames,
          Volumes,
          TotalVolume,
          OpeningDateTime,
          ClosingDateTime,
          RegaugeDateTime,
          OpeningProductFT,
          ClosingProductFT,
          RegaugeProductFT,
          OpeningProductInch,
          ClosingProductInch,
          RegaugeProductInch,
          OpeningProduct16,
          ClosingProduct16,
          RegaugeProduct16,
          OpeningWaterFT,
          ClosingWaterFT,
          RegaugeWaterFT,
          OpeningWaterInch,
          ClosingWaterInch,
          RegaugeWaterInch,
          OpeningWater16,
          ClosingWater16,
          RegaugeWater16,
          OpeningProductMetric,
          ClosingProductMetric,
          RegaugeProductMetric,
          OpeningWaterMetric,
          ClosingWaterMetric,
          RegaugeWaterMetric,
          OpeningTemperature,
          ClosingTemperature,
          RegaugeTemperature,
          OpeningDensity15oC,
          ClosingDensity15oC,
          RegaugeDensity15oC,
          Status,
          Remarks,
          Attachments,
          WithDenaturing,
          VolumeAtAir,
          VolumeAt60,
          SubmitCount,
          Submitted,
        },
      }
    );

    return res.json(result);
  } catch (error) {
    console.error("Failed to create tank truck issuance:", error);
    res.status(500).json({ error: "Failed to create tank truck issuance" });
  }
});

router.post("/getTankTruckIssuanceRecord", async (req, res) => {
  const { SessionID } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_GetTankTruckIssuanceRecord(:SessionID)",
      {
        replacements: {
          SessionID
        }
      }
    );
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetTankTruckIssuanceRecord:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/getTTINextSessionID", async (req, res) => {
  try {
    const result = await sequelize.query("CALL SP_GetTTINextSessionID()");
    res.json(result);
  } catch (error) {
    console.error("Error fetching getTTINextSessionID:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
