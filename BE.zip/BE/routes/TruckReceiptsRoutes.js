const express = require("express");
const router = express.Router();
const { sequelize } = require("../models"); // Adjust the path accordingly
const { TruckReceipts } = require("../models");

// POST API to create a new tanker receipt
router.post("/saveTruckReceiptTruckLoading", async (req, res) => {
  const {
    TRID,
    SessionID,
    TankID,
    CalibType,
    ProductID,
    Transaction,
    ClientNames,
    Volumes,
    TotalVolume,
    HaulerName,
    DriverFirstName,
    DriverLastName,
    TractorPlateNo,
    TrailerPlateNo,
    Attachments,
    TRNNo,
    ATLNo,
    TicketNo,
    LoadingRack,
    LRID,
    QuantityLoadedBase,
    QuantityLoadedAdditive,
    CompartmentLoadedBase,
    CompartmentLoadedAdditive,
    LoadingArmNo,
    MeterOpeningBase,
    MeterOpeningAdditive,
    MeterClosingBase,
    MeterClosingAdditive,
    LoadTimeOpening,
    LoadTimeClosing,
    Remarks,
    SubmitCount,
    Submitted,
    AdditiveCalibType,
    AdditiveTankID,
    AdditiveProductID,
    AdditiveClientNames,
    AdditiveLoadingArmNo,
  } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_SaveTruckReceiptTruckLoading(:TRID,:SessionID,:TankID,:CalibType,:ProductID,:Transaction,:ClientNames,:Volumes,:TotalVolume,:HaulerName,:DriverFirstName,:DriverLastName,:TractorPlateNo,:TrailerPlateNo,:Attachments,:TRNNo,:ATLNo,:TicketNo,:LoadingRack,:LRID,:QuantityLoadedBase,:QuantityLoadedAdditive,:CompartmentLoadedBase,:CompartmentLoadedAdditive,:LoadingArmNo,:MeterOpeningBase,:MeterOpeningAdditive,:MeterClosingBase,:MeterClosingAdditive,:LoadTimeOpening,:LoadTimeClosing,:Remarks,:SubmitCount, :Submitted, :AdditiveCalibType, :AdditiveTankID, :AdditiveProductID, :AdditiveClientNames, :AdditiveLoadingArmNo)",
      {
        replacements: {
          TRID,
          SessionID,
          TankID,
          CalibType,
          ProductID,
          Transaction,
          ClientNames,
          Volumes,
          TotalVolume,
          HaulerName,
          DriverFirstName,
          DriverLastName,
          TractorPlateNo,
          TrailerPlateNo,
          Attachments,
          TRNNo,
          ATLNo,
          TicketNo,
          LoadingRack,
          LRID,
          QuantityLoadedBase,
          QuantityLoadedAdditive,
          CompartmentLoadedBase,
          CompartmentLoadedAdditive,
          LoadingArmNo,
          MeterOpeningBase,
          MeterOpeningAdditive,
          MeterClosingBase,
          MeterClosingAdditive,
          LoadTimeOpening,
          LoadTimeClosing,
          Remarks,
          SubmitCount,
          Submitted,
          AdditiveCalibType,
          AdditiveTankID,
          AdditiveProductID,
          AdditiveClientNames,
          AdditiveLoadingArmNo,
        },
      }
    );

    return res.json(result);
  } catch (error) {
    console.error("Failed to create SP_saveTruckReceiptTruckLoading:", error);
    res
      .status(500)
      .json({ error: "Failed to create SP_saveTruckReceiptTruckLoading" });
  }
});

router.post("/getTruckReceiptTruckLoadingRecord", async (req, res) => {
  const { SessionID, Transaction } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_GetTruckReceiptTruckLoadingRecord(:SessionID, :Transaction)",
      {
        replacements: {
          SessionID,
          Transaction,
        },
      }
    );
    res.json(result);
  } catch (error) {
    console.error(
      "Error fetching SP_GetTruckReceiptTruckLoadingRecord:",
      error
    );
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/getTruckLoadingNextSessionID", async (req, res) => {
  try {
    const result = await sequelize.query(
      "CALL SP_GetTruckLoadingNextSessionID()"
    );
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetTruckLoadingNextSessionID:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/getTruckReceiptsNextSessionID", async (req, res) => {
  try {
    const result = await sequelize.query(
      "CALL SP_GetTruckReceiptsNextSessionID()"
    );
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetTruckReceiptsNextSessionID:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
