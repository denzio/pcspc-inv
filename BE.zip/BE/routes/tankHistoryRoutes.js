// routes/calibrationListT4Routes.js
const express = require('express');
const router = express.Router();
const { TankHistory } = require('../models');
const { sequelize } = require('../models'); // Adjust the path accordingly

router.post("/get-tank-history", async (req, res) => {
const { TankNumber } = req.body;
    try {
        const result = await sequelize.query(
        "CALL SP_GetTankHistoryDetails(:TankNumber)",
            {
                replacements: {
                    TankNumber,
                },
            }
        );
        
        return res.json(result);

    } catch (error) {
        console.error("Error Getting Tank History Details:", error);
        res.status(500).send("Error Getting Tank History Details.");
    }
});

module.exports = router;