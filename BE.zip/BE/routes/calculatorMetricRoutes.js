const express = require("express");
const router = express.Router();
const { sequelize } = require("../models"); // Adjust the path accordingly
const { raw } = require("mysql2");

router.post("/calculatemetric", async (req, res) => {
  try {
    const {
      TankID,
      OpeningFuel,
      OpeningWater,
      OpeningTemperature,
      OpeningDensity20,
      OpeningDensity15,
      ClosingFuel,
      ClosingWater,
      ClosingTemperature,
      ClosingDensity20,
      ClosingDensity15,
    } = req.body;

    // Call the stored procedure using Sequelize's query method
    const result = await sequelize.query(
      "CALL SP_CalculatorOpeningClosingMetric(:TankID, :OpeningFuel, :OpeningWater, :OpeningTemperature, :OpeningDensity20, :OpeningDensity15, :ClosingFuel, :ClosingWater, :ClosingTemperature, :ClosingDensity20, :ClosingDensity15)",
      {
        replacements: {
          TankID,
          OpeningFuel,
          OpeningWater,
          OpeningTemperature,
          OpeningDensity20,
          OpeningDensity15,
          ClosingFuel,
          ClosingWater,
          ClosingTemperature,
          ClosingDensity20,
          ClosingDensity15,
        },
        type: sequelize.QueryTypes.SELECT, // Use SELECT to return results
        raw: true,
      }
    );
    //console.log(result);
    return res.json(result);
  } catch (error) {
    console.error("Error:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/calculatemetricwhiteproduct", async (req, res) => {
  try {
    const {
      TankID,
      OpeningFuel,
      OpeningWater,
      OpeningTemperature,
      OpeningDensity15,
      ClosingFuel,
      ClosingWater,
      ClosingTemperature,
      ClosingDensity15,
    } = req.body;

    // Call the stored procedure using Sequelize's query method
    const result = await sequelize.query(
      "CALL SP_CalculatorOpeningClosingMetricWP(:TankID, :OpeningFuel, :OpeningWater, :OpeningTemperature, :OpeningDensity15, :ClosingFuel, :ClosingWater, :ClosingTemperature, :ClosingDensity15)",
      {
        replacements: {
          TankID,
          OpeningFuel,
          OpeningWater,
          OpeningTemperature,
          OpeningDensity15,
          ClosingFuel,
          ClosingWater,
          ClosingTemperature,
          ClosingDensity15,
        },
        type: sequelize.QueryTypes.SELECT, // Use SELECT to return results
        raw: true,
      }
    );
    //console.log(result);
    return res.json(result);
  } catch (error) {
    console.error("Error:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});
module.exports = router;
