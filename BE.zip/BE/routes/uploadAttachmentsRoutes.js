const express = require("express");
const router = express.Router();
const aws = require('aws-sdk');
const multer = require('multer');
const multerS3 = require('multer-s3');

// aws.config.update({
//     secretAccessKey: 'AKIAYWDI2CNZX4QP7WE4',
//     accessKeyId: '8kpjOlQPtUHOfY17ZP2ZZ4UMEOyMokJ8BXSvNmDZ',
//     region: 'us-east-1'
// });
const s3 = new aws.S3({
  accessKeyId: 'AKIAYWDI2CNZX4QP7WE4',
  secretAccessKey: '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',
  region: 'us-east-1'
});
//const s3 = new aws.S3();
// Dynamically set bucket name via environment variable or fallback to default
const bucketName = 'pcuploadattachments';
const upload = multer({
    storage: multerS3({
        s3: s3,
        bucket: bucketName,
        contentType: multerS3.AUTO_CONTENT_TYPE, // Auto-detect Content-Type
        key: function (req, file, cb) {
          cb(null, `${Date.now().toString()}-${file.originalname}`);
      }
    })
});

//5 is the maximum files that can be uploaded
router.post('/upload', upload.array('files', 5), (req, res) => {
  const files = req.files;
  try {
        if (files && files.length > 0) {
            const responseFiles = files.map(file => {
            const params = { Bucket: bucketName, Key: file.key, Expires: 24 * 60 * 60 };
            const url = s3.getSignedUrl('getObject', params);
            return {
                url: url,
                filename: file.originalname,
                mimeType: file.mimetype,
                size: file.size
            };
            });
          res.json({
              message: 'Files uploaded successfully',
              files: responseFiles
          });
      } else {
          res.status(400).send('File upload failed');
      }
  } catch (error) {
      console.error("File upload error:", error);
      res.status(500).send('Something went wrong!');
  }
});



module.exports = router;
