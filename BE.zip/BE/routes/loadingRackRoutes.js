// routes/calibrationListT4Routes.js
const express = require("express");
const router = express.Router();
const { LoadingRack } = require("../models");
const { sequelize } = require("../models"); // Adjust the path accordingly

// Get Loading Rack
router.get("/", async (req, res) => {
  try {
    const loadingRackDetails = await sequelize.query("CALL SP_GetLoadingRackDetails()");
    res.json(loadingRackDetails);
  } catch (error) {
    console.error("Error Loading Rack details:", error);
    res.status(500).json({ error: "Error Loading Rack details:" });
  }
});

// New Loading Rack
router.post("/add", (req, res) => {
  const newLoadingRack = req.body;

  LoadingRack.create(newLoadingRack)
    .then((data) => {
      res.status(201).json(data);
      console.log("New Loading Rack has been added");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("New Loading Rack has been added :", error);
    });
});

// Edit Loading Rack
router.put("/:id", (req, res) => {
  const loadingRackId = req.params.id;
  const updatedLoadingRackData = req.body;

  LoadingRack.update(updatedLoadingRackData, {
    where: { LRID: loadingRackId },
  })
    .then(() => {
      res.sendStatus(200); // Respond with success status
      console.log("Loading Rack has been updated");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("Error updating Loading Rack:", error);
    });
});

// Delete Loading Rack
router.delete("/:id", (req, res) => {
  const loadingRackId = req.params.id;

  LoadingRack.destroy({
    where: { LRID: loadingRackId },
  })
    .then(() => {
      res.sendStatus(204); // Respond with no content (success)
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
    });
});

module.exports = router;
