// routes/calibrationListT4Routes.js
const express = require("express");
const router = express.Router();
const { Site } = require("../models");
const { sequelize } = require("../models"); // Adjust the path accordingly

router.get("/", async (req, res) => {
  try {
    const productDetails = await sequelize.query(
      "CALL SP_GetLocationDetails()"
    );
    res.json(productDetails);
  } catch (error) {
    console.error("Error fetching Location Details:", error);
    res.status(500).json({ error: "Error fetching Location Details" });
  }
});

router.post("/add", (req, res) => {
  console.log(res.body);
  const newLocationSiteData = req.body;

  Site.create(newLocationSiteData)
    .then((data) => {
      res.status(201).json(data);
      console.log("New Location Site has been added");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("New Location Site not added due to :", error);
    });
});

// PUT route to update a specific location site by ID
router.put("/:id", (req, res) => {
  const locationSiteId = req.params.id;
  const updatedLocationSiteData = req.body;

  Site.update(updatedLocationSiteData, {
    where: { SiteID: locationSiteId },
  })
    .then(() => {
      res.sendStatus(200); // Respond with success status
      console.log("Location Site updated successfully");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("Error updating location site:", error);
    });
});

// DELETE route to delete a specific location site by ID
router.delete("/:id", (req, res) => {
  const locationSiteId = req.params.id;

  Site.destroy({
    where: { SiteID: locationSiteId },
  })
    .then(() => {
      res.sendStatus(204); // Respond with no content (success)
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
    });
});

module.exports = router;
