// routes/calibrationListT4Routes.js
const express = require("express");
const { Op, fn, col, where } = require('sequelize');
const router = express.Router();
const { User, Employee } = require("../models");
const { UserActivityLog } = require("../models");

router.post("/login", async (req, res) => {
  const validProxiesIp = ["34.233.42.34", "::1", "127.0.0.1"]; // philcoatal load proxy balancer, locahost, localhost
  const { username, password } = req.body;

  let clientIp = req.headers["x-forwarded-for"] || req.headers["x-real-ip"];
  if (clientIp) {
    clientIp = clientIp.split(",")[0]; // Take the first IP if there are multiple
  } else {
    clientIp = req.connection.remoteAddress; // Fallback to the direct IP
  }

  try {
    // Attempt to find the user by username and password
    const user = await User.findOne({
      where: { 
        [Op.and]: [
          where(fn('BINARY', col('UserName')), Op.eq, username),
          where(fn('BINARY', col('Password')), Op.eq, password),
        ]
      },
      attributes: [`UserName`, `EmployeeID`, `HasAccess`, `UserRoleID`],
    });

    if (user) {
      // Log the login attempt
      await UserActivityLog.create({
        EmployeeID: user.EmployeeID,
        ActionType: "Login Attempt",
        ActionDetails: `Login attempt for user ${username}.`,
        ClientIP: clientIp,
      });

      const employee = await Employee.findOne({
        where: { 
          [Op.and]: [
            where(fn('BINARY', col('EmployeeID')), Op.eq, user.EmployeeID),
          ]
        },
        attributes: [`FirstName`, `LastName`],
      });

      // Prepare the user data to send back. Exclude sensitive information.
      const userData = {
        FirstName: employee.FirstName,
        LastName: employee.LastName,
        EmployeeID: user.EmployeeID,
        UserName: user.UserName,
        HasAccess: user.HasAccess,
        UserRoleID: user.UserRoleID,
        // Add other user properties you might want to return here
      };
      //if (!username.includes("admin") && !validProxiesIp.includes(clientIp))
      //res.status(401).json({ message: "Unauthorized User/IP Proxy Address" });
      //Temporary
      if(user.HasAccess == 1){
        console.log("Authentication successful");
        console.log(user.EmployeeID);
        return res.json({
          message: "Login successful",
          user: userData,
        });
      }
      if(user.HasAccess == 0){
        return res.json({
          message: "Inactive login user",
          user: userData,
        });
      }
    }else{
      res.json({
        message: "Login Failed",
        user: null,
      });
    }
  } catch (error) {
    console.error("Error:", error);
    res.status(500).send("Error: " + error.message);
  }
});

// Get User
router.get("/", (req, res) => {
  User.findAll({
    attributes: [
      `UserID`,
      `EmployeeID`,
      `UserName`,
      `Password`,
      `HasAccess`,
      `UserRoleID`,
    ],
  })
    .then((data) => {
      res.json(data); // This will send the data as a JSON response
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
    });
});

// New User
router.post("/add", (req, res) => {
  const newUser = req.body;

  User.create(newUser)
    .then((data) => {
      res.status(201).json(data);
      console.log("New User has been added");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("New User has been added :", error);
    });
});

// Edit User
router.put("/:id", (req, res) => {
  const userID = req.params.id;
  const updatedUserData = req.body;

  User.update(updatedUserData, {
    where: { UserID: userID },
  })
    .then(() => {
      res.sendStatus(200); // Respond with success status
      console.log("User has been updated");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("Error updating User:", error);
    });
});

// Change Status
router.patch("/:id/status", (req, res) => {
  const userId = req.params.id;
  const newStatus = req.body.status;

  User.update(
    { HasAccess: newStatus },
    {
      where: { UserID: userId },
    }
  )
    .then((data) => {
      res.sendStatus(200); // Respond with success status
      console.log("User status updated successfully");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("Error updating user status:", error);
    });
});

// Delete User
router.delete("/:id", (req, res) => {
  const userID = req.params.id;

  User.destroy({
    where: { UserID: userID },
  })
    .then(() => {
      res.sendStatus(204); // Respond with no content (success)
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
    });
});

module.exports = router;
