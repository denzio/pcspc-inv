const express = require("express");
const router = express.Router();
const { sequelize } = require("../models"); // Adjust the path accordingly

router.post("/getLedgerTankDetails", async (req, res) => {
  try {
    const result = await sequelize.query("CALL SP_GetLedgerTankDetails()");
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetLedgerTankDetails:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/getLedgerTankRecords", async (req, res) => {
  const { TankID, Date } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_GetLedgerTankRecords( :TankID, :Date)",
      {
        replacements: {
          TankID,
          Date,
        },
      }
    );
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetLedgerTankRecords", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/getProductInventoryUllageReportDedicated", async (req, res) => {
  const { ClientID, Date } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_GetProductInventoryUllageReportDedicated( :ClientID, :Date)",
      {
        replacements: {
          ClientID,
          Date,
        },
      }
    );
    res.json(result);
  } catch (error) {
    console.error(
      "Error fetching SP_GetProductInventoryUllageReportDedicated",
      error
    );
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/getTankLevel", async (req, res) => {
  const { TankID } = req.body;
  try {
    const result = await sequelize.query("CALL SP_GetTankLevel( :TankID)", {
      replacements: {
        TankID,
      },
    });
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetTankLevel", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
