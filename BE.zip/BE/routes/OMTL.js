const express = require("express");
const router = express.Router();
const { sequelize } = require("../models"); // Adjust the path accordingly
const { OMTLMetric } = require("../models");

router.get("/metric", (req, res) => {
  OMTLMetric.findAll({
    attributes: [
      `OMTLID`,
      `TankID`,
      `ProductID`,
      `ClientID`,
      `TransactionType`,
      `DateTimeOpening`,
      `DateTimeClosing`,
      `GaugeFuelWaterOpening`,
      `GaugeFuelWaterClosing`,
      `GaugeWaterOpening`,
      `GaugeWaterClosing`,
      `AveTemperatureOpening`,
      `AveTemperatureClosing`,
      `DensityOpening`,
      `DensityClosing`,
      `CorrectionFactorVolOpening`,
      `CorrectionFactorVolClosing`,
      `TotalObservedVolOpening`,
      `TotalObservedVolClosing`,
      `FreeWaterVolOpening`,
      `FreeWaterVolClosing`,
      `GrossObservedVolOpening`,
      `GrossObservedVolClosing`,
      `GrossStdVolOpening`,
      `GrossStdVolClosing`,
      `NetStdVolOpening`,
      `NetStdVolClosing`,
      `WCFOpening`,
      `WCFClosing`,
      `MetricTonsOpening`,
      `MetricTonsClosing`,
      `LongTonsOpening`,
      `LongTonsClosing`,
      `Status`,
      `Memo,`,
      `USBbls`,
      `LitersMetricTons`,
      `LongTons`,
      `USBblsObsTemp`,
      `LitersObsTemp`,
      `HasClosing`,
      `DateCreated`,
    ],
  })
    .then((data) => {
      res.json(data);
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
    });
});

// Create new tank record
router.post("/metric/add", (req, res) => {
  const newOTMLMetric = req.body;
  console.log(newOTMLMetric);

  OMTLMetric.create(newOTMLMetric)
    .then((data) => {
      res.status(201).json(data);
      console.log("Added Metric Transaction");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("OMTL Metric Transaction not added due to :", error);
    });
});

router.post("/getOMTLRecords", async (req, res) => {
  const { SessionID, Transaction } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_GetOMTLRecords(:SessionID, :Transaction)",
      {
        replacements: {
          SessionID,
          Transaction,
        },
      }
    );
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetOMTLRecords", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/getOMTLRecordsByDate", async (req, res) => {
  const {
    SessionID,
    Transaction,
    StartDate = null,
    EndDate = null,
    TransactionStatus = "live",
  } = req.body;

  try {
    const result = await sequelize.query(
      "CALL SP_GetOMTLRecordsByDate(:SessionID, :Transaction, :StartDate, :EndDate, :TransactionStatus)",
      {
        replacements: {
          SessionID,
          Transaction,
          StartDate,
          EndDate,
          TransactionStatus,
        },
      }
    );
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetOMTLRecordsByDate", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/onSubmitTransaction", async (req, res) => {
  const { SessionID, Transaction } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_OnSubmitTransaction(:SessionID, :Transaction)",
      {
        replacements: {
          SessionID,
          Transaction,
        },
      }
    );
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetOMTLRecords", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/onGetTransactionDetails", async (req, res) => {
  const { Transaction } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_GetTransactionDetails( :Transaction)",
      {
        replacements: {
          Transaction,
        },
      }
    );
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetTransactionDetails", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
