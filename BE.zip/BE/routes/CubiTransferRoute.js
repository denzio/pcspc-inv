const express = require("express");
const router = express.Router();
const { sequelize } = require("../models"); // Adjust the path accordingly
const { CubiTransfer } = require("../models");

// POST API to create a new tanker receipt
router.post("/saveCubiTransfer", async (req, res) => {
  const {
    CTID,
    TankIssuingReceiving,
    SessionID,
    TankID,
    CalibType,
    ProductID,
    Transaction,
    ClientNames,
    Volumes,
    TotalVolume,
    OpeningDateTime,
    ClosingDateTime,
    RegaugeDateTime,
    OpeningProductFT,
    ClosingProductFT,
    RegaugeProductFT,
    OpeningProductInch,
    ClosingProductInch,
    RegaugeProductInch,
    OpeningProduct16,
    ClosingProduct16,
    RegaugeProduct16,
    OpeningWaterFT,
    ClosingWaterFT,
    RegaugeWaterFT,
    OpeningWaterInch,
    ClosingWaterInch,
    RegaugeWaterInch,
    OpeningWater16,
    ClosingWater16,
    RegaugeWater16,
    OpeningProductMetric,
    ClosingProductMetric,
    RegaugeProductMetric,
    OpeningWaterMetric,
    ClosingWaterMetric,
    RegaugeWaterMetric,
    OpeningTemperature,
    ClosingTemperature,
    RegaugeTemperature,
    OpeningDensity15oC,
    ClosingDensity15oC,
    RegaugeDensity15oC,
    Status,
    Remarks,
    Attachments,
  } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_CubiTransfer(:CTID, :TankIssuingReceiving, :SessionID, :TankID, :CalibType, :ProductID, :Transaction, :ClientNames, :Volumes, :TotalVolume, :OpeningDateTime, :ClosingDateTime,:RegaugeDateTime, :OpeningProductFT, :ClosingProductFT, :RegaugeProductFT, :OpeningProductInch, :ClosingProductInch, :RegaugeProductInch, :OpeningProduct16, :ClosingProduct16,:RegaugeProduct16, :OpeningWaterFT, :ClosingWaterFT, :RegaugeWaterFT, :OpeningWaterInch, :ClosingWaterInch, :RegaugeWaterInch, :OpeningWater16, :ClosingWater16, :RegaugeWater16, :OpeningProductMetric, :ClosingProductMetric, :RegaugeProductMetric, :OpeningWaterMetric, :ClosingWaterMetric, :RegaugeWaterMetric, :OpeningTemperature, :ClosingTemperature, :RegaugeTemperature, :OpeningDensity15oC, :ClosingDensity15oC, :RegaugeDensity15oC, :Status, :Remarks, :Attachments)",
      {
        replacements: {
          CTID,
          TankIssuingReceiving,
          SessionID,
          TankID,
          CalibType,
          ProductID,
          Transaction,
          ClientNames,
          Volumes,
          TotalVolume,
          OpeningDateTime,
          ClosingDateTime,
          RegaugeDateTime,
          OpeningProductFT,
          ClosingProductFT,
          RegaugeProductFT,
          OpeningProductInch,
          ClosingProductInch,
          RegaugeProductInch,
          OpeningProduct16,
          ClosingProduct16,
          RegaugeProduct16,
          OpeningWaterFT,
          ClosingWaterFT,
          RegaugeWaterFT,
          OpeningWaterInch,
          ClosingWaterInch,
          RegaugeWaterInch,
          OpeningWater16,
          ClosingWater16,
          RegaugeWater16,
          OpeningProductMetric,
          ClosingProductMetric,
          RegaugeProductMetric,
          OpeningWaterMetric,
          ClosingWaterMetric,
          RegaugeWaterMetric,
          OpeningTemperature,
          ClosingTemperature,
          RegaugeTemperature,
          OpeningDensity15oC,
          ClosingDensity15oC,
          RegaugeDensity15oC,
          Status,
          Remarks,
          Attachments,
        },
      }
    );

    return res.json(result);
  } catch (error) {
    console.error("Failed to create SP_CubiTransfer:", error);
    res.status(500).json({ error: "Failed to create SP_CubiTransfer" });
  }
});

router.post("/getCubiTransferRecord", async (req, res) => {
  const { SessionID, Transaction } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_GetInterTankCubiConsolidationRecord(:SessionID, :Transaction)",
      {
        replacements: {
          SessionID,
          Transaction,
        },
      }
    );
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetCubiTransferRecord:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/getCubiTransferNextSessionID", async (req, res) => {
  try {
    const result = await sequelize.query(
      "CALL SP_GetCubiTransferNextSessionID()"
    );
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetCubiTransferNextSessionID:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
