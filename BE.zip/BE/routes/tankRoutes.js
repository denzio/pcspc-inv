// routes/calibrationListT4Routes.js
const express = require("express");
const router = express.Router();
const { sequelize } = require("../models"); // Adjust the path accordingly
const { Tank } = require("../models");

router.get("/", (req, res) => {
  Tank.findAll({
    attributes: [
      `TankID`,
      `TankNumber`,
      `CalibType`,
      `ShellCapacity_BBLS`,
      `InstallationDate`,
      `SiteID`,
      `TankHeight_FT`,
      `TankDiameter_FT`,
      `SafeFill_BBLS`,
      `CalibrationDate`,
      `MaintenanceSchedule`,
      `Status`,
      `Memo`,
      `UllageCapacity`,
      `DeadstockVolume_BBLS`,
      `MaximumCapacity`,
      "WithCenterTable",
      "ReferenceHeight_Center",
      "ReferenceHeight_Side",
    ],
  })
    .then((data) => {
      res.json(data); // This will send the data as a JSON response
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
    });
});

router.get("/nextTankID", (req, res) => {
  Tank.findOne({
    attributes: [[sequelize.fn("MAX", sequelize.col("TankID")), "nextTankID"]],
    raw: true,
  })
    .then((data) => {
      const nextTankID = data.nextTankID + 1;
      res.json({ nextTankID }); // This will send the nextTankID as a JSON response
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
    });
});

router.get("/get-tank-details", async (req, res) => {
  try {
    const tankDetails = await sequelize.query("CALL SP_GetTankDetails()");
    res.json(tankDetails);
  } catch (error) {
    console.error("Error fetching tank details:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/get-tank-view", async (req, res) => {
  const { TankNumber, ContractType, ProductName } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_GetTankView(:TankNumber, :ContractType, :ProductName)",
      {
        replacements: {
          TankNumber,
          ContractType,
          ProductName,
        },
      }
    );

    return res.json(result);
  } catch (error) {
    console.error("Error Getting Tank Details:", error);
    res.status(500).send("Error Getting Tank Details.");
  }
});

router.post("/get-tank-details-For-Edit", async (req, res) => {
  const { TankNumber, ContractType, ProductName } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_GetTankDetailsForEdit(:TankNumber, :ContractType, :ProductName)",
      {
        replacements: {
          TankNumber,
          ContractType,
          ProductName,
        },
      }
    );

    return res.json(result);
  } catch (error) {
    console.error("Error Getting Tank Edit Details:", error);
    res.status(500).send("Error Getting Tank Edit Details.");
  }
});

// Create new tank record
router.post("/add", (req, res) => {
  const newTank = req.body;

  Tank.create(newTank)
    .then((data) => {
      res.status(201).json(data);
      console.log("New tank has been added");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("New tank not added due to :", error);
    });
});

// Define the route for adding a new tank entry
router.post("/add-tank-entry", async (req, res) => {
  try {
    const {
      TankID,
      TankNumber,
      InstallationDate,
      ContractType,
      SiteID,
      Status,
      Memo,
      ClientID = null,
      ProductID,
    } = req.body;

    // Execute the stored procedure
    await sequelize.query(
      "CALL SP_SaveTankData(:TankID, :TankNumber, :InstallationDate, :SiteID, :Status, :Memo, :ProductID, :ContractType, :ClientID)",
      {
        replacements: {
          TankID,
          TankNumber,
          ContractType,
          InstallationDate,
          SiteID,
          Status,
          Memo,
          ClientID,
          ProductID,
        },
      }
    );

    res.json({ message: "Tank entry added successfully." });
  } catch (error) {
    console.error("Error adding tank entry:", error);
    res.status(500).send("Error adding tank entry.");
  }
});

// PUT route to update a specific tank by ID
router.put("/:id", (req, res) => {
  const tankId = req.params.id;
  const updatedTankData = req.body;

  Tank.update(updatedTankData, {
    where: { TankID: tankId },
  })
    .then(() => {
      res.sendStatus(200); // Respond with success status
      console.log("Tank updated successfully");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("Error updating tank:", error);
    });
});

// DELETE route to delete a specific tank by ID
router.delete("/:id", (req, res) => {
  const tankId = req.params.id;

  Tank.destroy({
    where: { TankID: tankId },
  })
    .then(() => {
      res.sendStatus(204); // Respond with no content (success)
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
    });
});

//Edit Tank Details on import Calibration
router.post("/import", async (req, res) => {
  const {
    TankNumber,
    CalibType,
    ShellCapacity_BBLS,
    SafeFill_BBLS,
    UllageCapacity,
    DeadstockVolume_BBLS,
    TankHeight_FT,
    TankDiameter_FT,
    MaximumCapacity,
    WithCenterTable,
    ReferenceHeight_Center,
    ReferenceHeight_Side,
    calibration_date,
    Memo,
  } = req.body;

  try {
    // Execute the stored procedure
    await sequelize.query(
      "CALL SP_UpdateTankDetailsOnImport(:TankNumber, :CalibType, :ShellCapacity_BBLS, :SafeFill_BBLS, :UllageCapacity, :DeadstockVolume_BBLS, :TankHeight_FT, :TankDiameter_FT, :MaximumCapacity, :WithCenterTable, :ReferenceHeight_Center, :ReferenceHeight_Side, :calibration_date,:Memo)",
      {
        replacements: {
          TankNumber,
          CalibType,
          ShellCapacity_BBLS,
          SafeFill_BBLS,
          UllageCapacity,
          DeadstockVolume_BBLS,
          TankHeight_FT,
          TankDiameter_FT,
          MaximumCapacity,
          WithCenterTable,
          ReferenceHeight_Center,
          ReferenceHeight_Side,
          calibration_date,
          Memo,
        },
      }
    );

    res.json({ message: "Tank Import Updated successfully." });
  } catch (error) {
    console.error("Error Tank Import:", error);
    res.status(500).send("Error Tank Import:");
  }
});

//Inactive & Active Tank Status
router.patch("/:id/status", async (req, res) => {
  const TankID = req.params.id;
  const Status = req.body.status;

  try {
    const result = await sequelize.query(
      "CALL SP_DeactivateTank(:TankID, :Status)",
      {
        replacements: {
          TankID,
          Status,
        },
      }
    );

    res.json(result);
  } catch (error) {
    console.error("Error on DeactivateTank:", error);
    res.status(500).send("Error on DeactivateTank:");
  }
});

router.post("/export", async (req, res) => {
  const { TankID, CalibType } = req.body;

  try {
    // Execute the stored procedure
    const result = await sequelize.query(
      "CALL SP_ExportTankDetails(:TankID, :CalibType)",
      {
        replacements: {
          TankID,
          CalibType,
        },
      }
    );

    res.json(result);
  } catch (error) {
    console.error("Error Tank export:", error);
    res.status(500).send("Error Tank export:");
  }
});

router.post("/checkSiteID", async (req, res) => {
  const siteId = req.body.siteID;
  try {
    const tank = await Tank.findOne({ where: { SiteID: siteId } });

    if (tank) {
      res.status(200).json({ exists: true });
      console.log("SiteID exists in Tank Table");
    } else {
      res.status(200).json({ exists: false });
      console.log("SiteID does not exist in Tank Table");
    }
  } catch (error) {
    res.status(500).send("Error: " + error.message);
    console.error("Error while checking SiteID: ", error);
  }
});

router.post("/download", async (req, res) => {
  const { TankID } = req.body;

  try {
    // Execute the stored procedure
    const result = await sequelize.query("CALL SP_DLCalibTable(:TankID)", {
      replacements: {
        TankID,
      },
    });

    res.json(result);
  } catch (error) {
    console.error("Error download Tank  calibration:", error);
    res.status(500).send("Error download Tank  calibration:");
  }
});

module.exports = router;
