// routes/calibrationListT4Routes.js
const express = require("express");
const router = express.Router();
const { sequelize } = require("../models"); // Adjust the path accordingly
const { CTPTransaction } = require("../models");
// Helper function to format dates
// Helper function to format dates to "YYYY-MM-DD HH:MM:SS"
const formatDate = (dateString) => {
  const date = new Date(dateString);
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, "0");
  const day = date.getDate().toString().padStart(2, "0");
  const hours = date.getHours().toString().padStart(2, "0");
  const minutes = date.getMinutes().toString().padStart(2, "0");
  const seconds = date.getSeconds().toString().padStart(2, "0");
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
};
router.get("/", (req, res) => {
  CTPTransaction.findAll({
    attributes: [
      "CTPTID",
      "TankID",
      "ClientID",
      "ProductID",
      "TankNumber",
      "CompanyName",
      "ProductName",
      "Volume",
      "ContractStartDate",
      "ContractEndDate",
      "ContractType",
      "Remarks",
    ],
  })
    .then((data) => {
      res.json(data); // This will send the data as a JSON response
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
    });
});

// POST route for saving data
router.post("/add", (req, res) => {
  // Assuming req.body contains the data to save
  CTPTransaction.create(req.body)
    .then((data) => {
      res.status(201).json(data); // Send back the created record
    })
    .catch((error) => {
      res.status(400).send("Error: " + error.message);
    });
});

// Route to execute SP_SaveCTPData
// Route to execute SP_SaveCTPData stored procedure
router.post("/saveClientCTP", async (req, res) => {
  try {
    const {
      ClientID,
      CompanyName,
      Status,
      TankID,
      TankNumber,
      ProductID,
      ContractType,
      Volume,
      ContractStartDate,
      ContractEndDate,
      Remarks,
    } = req.body;

    // Execute the stored procedure
    await sequelize.query(
      "CALL SP_CTPContract(:ClientID, :CompanyName, :Status, :TankID, :TankNumber, :ProductID, :ContractType, :Volume, :ContractStartDate, :ContractEndDate, :Remarks)",
      {
        replacements: {
          ClientID,
          CompanyName,
          Status,
          TankID,
          TankNumber,
          ProductID,
          ContractType,
          Volume,
          ContractStartDate,
          ContractEndDate,
          Remarks,
        },
      }
    );

    res
      .status(200)
      .json({ message: "Client and CTP data saved successfully." });
  } catch (error) {
    console.error("Error executing stored procedure:", error);
    res.status(500).send("Error executing stored procedure: " + error.message);
  }
});
router.post("/getContractsByClient", async (req, res) => {
  const { ClientID } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_GetContractsByClient(:ClientID)",
      {
        replacements: {
          ClientID,
        },
      }
    );

    return res.json(result);
  } catch (error) {
    console.error("Error executing stored procedure:", error);
    res.status(500).send("Error executing stored procedure: " + error.message);
  }
});
// Route to execute UpdateClientCTPCTPTransaction stored procedure
router.post("/updateClientCTP", async (req, res) => {
  try {
    const {
      ClientID,
      CompanyName,
      Status,
      TankID,
      TankNumber,
      ProductID,
      ContractType,
      Volume,
      ContractStartDate,
      ContractEndDate,
      Remarks,
    } = req.body;

    // Execute the stored procedure
    await sequelize.query(
      "CALL SP_CTPContract(:ClientID, :CompanyName, :Status, :TankID, :TankNumber, :ProductID, :ContractType, :Volume, :ContractStartDate, :ContractEndDate, :Remarks)",
      {
        replacements: {
          ClientID,
          CompanyName,
          Status,
          TankID,
          TankNumber,
          ProductID,
          ContractType,
          Volume,
          ContractStartDate,
          ContractEndDate,
          Remarks,
        },
      }
    );

    res
      .status(200)
      .json({ message: "Client and CTP data updated successfully." });
  } catch (error) {
    console.error("Error executing stored procedure:", error);
    res.status(500).send("Error executing stored procedure: " + error.message);
  }
});

module.exports = router;
