// routes/calibrationListT4Routes.js
const express = require("express");
const router = express.Router();
const { Employee } = require("../models");
const { sequelize } = require("../models"); // Adjust the path accordingly

// Get Employee
router.get("/", async (req, res) => {
  try {
    const employeeDetails = await sequelize.query("CALL SP_GetEmployeeDetails()");
    res.json(employeeDetails);
  } catch (error) {
    console.error("Error Employee details:", error);
    res.status(500).json({ error: "Error Employee details:" });
  }
});

// New Employee
router.post("/add", (req, res) => {
  const newEmployee = req.body;

  Employee.create(newEmployee)
    .then((data) => {
      res.status(201).json(data);
      console.log("New Employee has been added");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("New Employee has been added :", error);
    });
});

// Edit Employee
router.put("/:id", (req, res) => {
  const employeeID = req.params.id;
  const updatedEmployeeData = req.body;

  Employee.update(updatedEmployeeData, {
    where: { EmployeeID: employeeID },
  })
    .then(() => {
      res.sendStatus(200); // Respond with success status
      console.log("Employee has been updated");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("Error updating Employee:", error);
    });
});

// Change Status
router.patch("/:id/status", async (req, res) => {
  const employeeId = req.params.id;
  const newStatus = req.body.status;

  try {
    const employeeDetails = await sequelize.query(
      "CALL SP_UpdateEmployeeDetails(:employeeId, :newStatus)",
      {
        replacements: {
          employeeId,
          newStatus,
        },
      }
    );
    res.json(employeeDetails);
  } catch (error) {
    console.error("Error fetching Employee details:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Delete Employee
router.delete("/:id", (req, res) => {
  const employeeId = req.params.id;

  Employee.destroy({
    where: { EmployeeId: employeeId },
  })
    .then(() => {
      res.sendStatus(204); // Respond with no content (success)
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
    });
});

module.exports = router;
