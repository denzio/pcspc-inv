// routes/calibrationListT4Routes.js
const express = require('express');
const router = express.Router();
const { CalibrationListT4 } = require('../models');

router.get('/', (req, res) => { 
    CalibrationListT4.findAll({
        attributes: ['API'],
        group: ['API'],
    })
    .then(data => {
        res.json(data); // This will send the data as a JSON response
    })
    .catch(error => {
        res.status(500).send('Error: ' + error.message);
    });
});

module.exports = router;