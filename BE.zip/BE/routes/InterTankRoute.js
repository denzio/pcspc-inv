const express = require("express");
const router = express.Router();
const { sequelize } = require("../models"); // Adjust the path accordingly
const { InterTank } = require("../models");

// POST API to create a new tanker receipt
router.post("/saveInterTankCubiConsolidation", async (req, res) => {
  const {
    ITID,
    TankIssuingReceiving,
    SessionID,
    TankID,
    CalibType,
    ProductID,
    Transaction,
    ClientNames,
    PaperTransfer,
    Volumes,
    TotalVolume,
    OpeningDateTime,
    ClosingDateTime,
    RegaugeDateTime,
    OpeningProductFT,
    ClosingProductFT,
    RegaugeProductFT,
    OpeningProductInch,
    ClosingProductInch,
    RegaugeProductInch,
    OpeningProduct16,
    ClosingProduct16,
    RegaugeProduct16,
    OpeningWaterFT,
    ClosingWaterFT,
    RegaugeWaterFT,
    OpeningWaterInch,
    ClosingWaterInch,
    RegaugeWaterInch,
    OpeningWater16,
    ClosingWater16,
    RegaugeWater16,
    OpeningProductMetric,
    ClosingProductMetric,
    RegaugeProductMetric,
    OpeningWaterMetric,
    ClosingWaterMetric,
    RegaugeWaterMetric,
    OpeningTemperature,
    ClosingTemperature,
    RegaugeTemperature,
    OpeningDensity15oC,
    ClosingDensity15oC,
    RegaugeDensity15oC,
    Status,
    Remarks,
    Attachments,
    SubmitCount,
    Submitted,
  } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_InterTankCubiConsolidation(:ITID, :TankIssuingReceiving, :SessionID, :TankID, :CalibType, :ProductID, :Transaction, :ClientNames, :PaperTransfer, :Volumes, :TotalVolume, :OpeningDateTime, :ClosingDateTime,:RegaugeDateTime, :OpeningProductFT, :ClosingProductFT, :RegaugeProductFT, :OpeningProductInch, :ClosingProductInch, :RegaugeProductInch, :OpeningProduct16, :ClosingProduct16,:RegaugeProduct16, :OpeningWaterFT, :ClosingWaterFT, :RegaugeWaterFT, :OpeningWaterInch, :ClosingWaterInch, :RegaugeWaterInch, :OpeningWater16, :ClosingWater16, :RegaugeWater16, :OpeningProductMetric, :ClosingProductMetric, :RegaugeProductMetric, :OpeningWaterMetric, :ClosingWaterMetric, :RegaugeWaterMetric, :OpeningTemperature, :ClosingTemperature, :RegaugeTemperature, :OpeningDensity15oC, :ClosingDensity15oC, :RegaugeDensity15oC, :Status, :Remarks, :Attachments, :SubmitCount, :Submitted)",
      {
        replacements: {
          ITID,
          TankIssuingReceiving,
          SessionID,
          TankID,
          CalibType,
          ProductID,
          Transaction,
          ClientNames,
          PaperTransfer,
          Volumes,
          TotalVolume,
          OpeningDateTime,
          ClosingDateTime,
          RegaugeDateTime,
          OpeningProductFT,
          ClosingProductFT,
          RegaugeProductFT,
          OpeningProductInch,
          ClosingProductInch,
          RegaugeProductInch,
          OpeningProduct16,
          ClosingProduct16,
          RegaugeProduct16,
          OpeningWaterFT,
          ClosingWaterFT,
          RegaugeWaterFT,
          OpeningWaterInch,
          ClosingWaterInch,
          RegaugeWaterInch,
          OpeningWater16,
          ClosingWater16,
          RegaugeWater16,
          OpeningProductMetric,
          ClosingProductMetric,
          RegaugeProductMetric,
          OpeningWaterMetric,
          ClosingWaterMetric,
          RegaugeWaterMetric,
          OpeningTemperature,
          ClosingTemperature,
          RegaugeTemperature,
          OpeningDensity15oC,
          ClosingDensity15oC,
          RegaugeDensity15oC,
          Status,
          Remarks,
          Attachments,
          SubmitCount,
          Submitted,
        },
      }
    );

    return res.json(result);
  } catch (error) {
    console.error("Failed to create SP_InterTankCubiConsolidation:", error);
    res
      .status(500)
      .json({ error: "Failed to create SP_InterTankCubiConsolidation" });
  }
});

router.post("/getInterTankCubiConsolidationRecord", async (req, res) => {
  const { SessionID, Transaction } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_GetInterTankCubiConsolidationRecord(:SessionID, :Transaction)",
      {
        replacements: {
          SessionID,
          Transaction,
        },
      }
    );
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetVesselTankBunkeringRecord:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/getInterTankNextSessionID", async (req, res) => {
  try {
    const result = await sequelize.query("CALL SP_GetInterTankNextSessionID()");
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetInterTankNextSessionID:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
