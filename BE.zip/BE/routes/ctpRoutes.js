// routes/calibrationListT4Routes.js
const express = require("express");
const router = express.Router();
const { CTP } = require("../models");
const { sequelize } = require("../models"); // Adjust the path accordingly

router.post("/", async (req, res) => {
  try {
    const { ClientID } = req.body;
    // Call the stored procedure using Sequelize's query method
    const result = await sequelize.query("CALL SP_GetCTPDetails(:ClientID)", {
      replacements: {
        ClientID,
      },
    });
    //console.log(result);
    return res.json(result);
  } catch (error) {
    console.error("Error:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/NewTank", async (req, res) => {
  try {
    const { TankID, ProductID, ContractType } = req.body;
    if (!TankID || !ProductID || !ContractType) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    const newTank = await CTP.create({
      TankID: parseInt(TankID),
      ProductID: parseInt(ProductID),
      ContractType,
    });

    return res.json(newTank);
  } catch (error) {
    console.error("Error:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/CTPCalculator", async (req, res) => {
  try {
    const CalculatorDetails = await sequelize.query(
      "CALL SP_GetCalculatorDetails()"
    );
    res.json(CalculatorDetails);
  } catch (error) {
    console.error("Error fetching calculator details:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
