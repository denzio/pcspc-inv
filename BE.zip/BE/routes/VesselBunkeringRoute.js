const express = require("express");
const router = express.Router();
const { sequelize } = require("../models"); // Adjust the path accordingly
const { VesselBunkering } = require("../models");

// POST API to create a new tanker receipt
router.post("/saveVesselBunkering", async (req, res) => {
  const {
    TRID,
    SessionID,
    TankID,
    CalibType,
    ProductID,
    Transaction,
    GTicketNum,
    ClientNames,
    Volumes,
    TotalVolume,
    VesselName,
    VONumber,
    OpeningDateTime,
    ClosingDateTime,
    RegaugeDateTime,
    OpeningProductFT,
    ClosingProductFT,
    RegaugeProductFT,
    OpeningProductInch,
    ClosingProductInch,
    RegaugeProductInch,
    OpeningProduct16,
    ClosingProduct16,
    RegaugeProduct16,
    OpeningWaterFT,
    ClosingWaterFT,
    RegaugeWaterFT,
    OpeningWaterInch,
    ClosingWaterInch,
    RegaugeWaterInch,
    OpeningWater16,
    ClosingWater16,
    RegaugeWater16,
    OpeningProductMetric,
    ClosingProductMetric,
    RegaugeProductMetric,
    OpeningWaterMetric,
    ClosingWaterMetric,
    RegaugeWaterMetric,
    OpeningTemperature,
    ClosingTemperature,
    RegaugeTemperature,
    OpeningDensity15oC,
    ClosingDensity15oC,
    RegaugeDensity15oC,
    Status,
    Remarks,
    Attachments,
    WithDenaturing,
    VolumeAtAir,
    VolumeAt60,
    SubmitCount,
    Submitted,
  } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_VesselBunkering(:TRID, :SessionID, :TankID, :CalibType, :ProductID, :Transaction, :GTicketNum, :ClientNames, :Volumes, :TotalVolume, :VesselName, :VONumber, :OpeningDateTime, :ClosingDateTime,:RegaugeDateTime, :OpeningProductFT, :ClosingProductFT, :RegaugeProductFT, :OpeningProductInch, :ClosingProductInch, :RegaugeProductInch, :OpeningProduct16, :ClosingProduct16,:RegaugeProduct16, :OpeningWaterFT, :ClosingWaterFT, :RegaugeWaterFT, :OpeningWaterInch, :ClosingWaterInch, :RegaugeWaterInch, :OpeningWater16, :ClosingWater16, :RegaugeWater16, :OpeningProductMetric, :ClosingProductMetric, :RegaugeProductMetric, :OpeningWaterMetric, :ClosingWaterMetric, :RegaugeWaterMetric, :OpeningTemperature, :ClosingTemperature, :RegaugeTemperature, :OpeningDensity15oC, :ClosingDensity15oC, :RegaugeDensity15oC, :Status, :Remarks, :Attachments, :WithDenaturing, :VolumeAtAir, :VolumeAt60, :SubmitCount, :Submitted)",
      {
        replacements: {
          TRID,
          SessionID,
          TankID,
          CalibType,
          ProductID,
          Transaction,
          GTicketNum,
          ClientNames,
          Volumes,
          TotalVolume,
          VesselName,
          VONumber,
          OpeningDateTime,
          ClosingDateTime,
          RegaugeDateTime,
          OpeningProductFT,
          ClosingProductFT,
          RegaugeProductFT,
          OpeningProductInch,
          ClosingProductInch,
          RegaugeProductInch,
          OpeningProduct16,
          ClosingProduct16,
          RegaugeProduct16,
          OpeningWaterFT,
          ClosingWaterFT,
          RegaugeWaterFT,
          OpeningWaterInch,
          ClosingWaterInch,
          RegaugeWaterInch,
          OpeningWater16,
          ClosingWater16,
          RegaugeWater16,
          OpeningProductMetric,
          ClosingProductMetric,
          RegaugeProductMetric,
          OpeningWaterMetric,
          ClosingWaterMetric,
          RegaugeWaterMetric,
          OpeningTemperature,
          ClosingTemperature,
          RegaugeTemperature,
          OpeningDensity15oC,
          ClosingDensity15oC,
          RegaugeDensity15oC,
          Status,
          Remarks,
          Attachments,
          WithDenaturing,
          VolumeAtAir,
          VolumeAt60,
          SubmitCount,
          Submitted,
        },
      }
    );

    return res.json(result);
  } catch (error) {
    console.error("Failed to create VesselBunkering:", error);
    res.status(500).json({ error: "Failed to create VesselBunkering" });
  }
});

router.post("/getVesselBunkeringRecord", async (req, res) => {
  const { SessionID, Transaction } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_GetVesselTankBunkeringRecord(:SessionID, :Transaction)",
      {
        replacements: {
          SessionID,
          Transaction,
        },
      }
    );
    res.json(result);
  } catch (error) {
    console.error("Error fetching GetVesselBunkeringRecord:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/getVesselBunkeringNextSessionID", async (req, res) => {
  try {
    const result = await sequelize.query(
      "CALL SP_GetVesselBunkeringNextSessionID()"
    );
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetVesselBunkeringNextSessionID:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
