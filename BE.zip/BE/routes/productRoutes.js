// routes/calibrationListT4Routes.js
const express = require("express");
const router = express.Router();
const { Product } = require("../models");
const { sequelize } = require("../models"); // Adjust the path accordingly

router.get("/", async (req, res) => {
  try {
    const productDetails = await sequelize.query(
      "CALL SP_GetProductsDetails()"
    );
    res.json(productDetails);
  } catch (error) {
    console.error("Error fetching Product Details:", error);
    res.status(500).json({ error: "Error fetching Product Details" });
  }
});

router.post("/add", (req, res) => {
  console.log(res.body);
  const newProductData = req.body;

  Product.create(newProductData)
    .then((data) => {
      res.status(201).json(data);
      console.log("New product has been added");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("New Product not added due to :", error);
    });
});

// PUT route to update a specific product by ID
router.put("/:id", (req, res) => {
  const productid = req.params.id;
  const updatedProductData = req.body;

  Product.update(updatedProductData, {
    where: { ProductID: productid },
  })
    .then(() => {
      res.sendStatus(200); // Respond with success status
      console.log("Product updated successfully");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("Error updating product:", error);
    });
});

// DELETE route to delete a specific product by ID
router.delete("/:id", (req, res) => {
  const productId = req.params.id;

  Product.destroy({
    where: { ProductID: productId },
  })
    .then(() => {
      res.sendStatus(204); // Respond with no content (success)
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
    });
});
module.exports = router;
