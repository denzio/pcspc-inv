const express = require("express");
const router = express.Router();
const { CalibrationMetric } = require("../models");
const { sequelize } = require("../models");

router.get("/", (req, res) => {
  const { csvStream } = req.body;
  try {
    res.json({ message: "EDGAR Data inserted successfully" });
  } catch (error) {
    res.status(500).send("EDGAR Error: " + error.message);
  }
});

router.post("/add", async (req, res) => {
  const csvData = req.body;
  const calibrationData = csvData.map((row) => {
    const [employeeID, tankID, Calibration, fuel, water, calibrationDate] =
      row.split(",");
    const fuelValue = parseFloat(fuel);
    const waterValue = parseFloat(water);
    const calibrationValue = parseFloat(Calibration);

    // Check if the Calibration value is parseable as a float
    if (isNaN(calibrationValue)) {
      return null;
    }

    return {
      EmployeeID: employeeID,
      TankID: tankID,
      Calibration: calibrationValue,
      Fuel: isNaN(fuelValue) ? null : fuelValue,
      Water: isNaN(waterValue) ? null : waterValue,
      CalibrationDate: new Date(calibrationDate),
    };
  });

  // Filter out the null elements (invalid rows)
  const filteredData = calibrationData.filter((data) => data !== null);

  try {
    const data = await migrateAndCreate(filteredData);
    res.status(201).json(data);
    console.log(
      "Calibration for " + calibrationData[0].TankID + " has been added"
    );
  } catch (error) {
    res.status(500).send("Error: " + error.message);
    console.error("New Calibration not added due to :", error);
  }
});

const migrateAndCreate = async (calibrationData) => {
  try {
    const p_CalibrationType = "METRIC";
    const p_TankID = calibrationData[0].TankID;
    await sequelize.query(
      "CALL SP_MoveObsoleteCalibrationData(:p_CalibrationType, :p_TankID)",
      {
        replacements: {
          p_CalibrationType,
          p_TankID,
        },
      }
    );
    // Insert new calibration data into CalibrationMetric
    await CalibrationMetric.bulkCreate(calibrationData);

    //return newCalibrations;
  } catch (error) {
    console.error("Error: ", error);
    throw error;
  }
};

module.exports = router;
