const express = require('express');
const router = express.Router();
const { sequelize } = require('../models'); // Adjust the path accordingly
const { raw } = require('mysql2');

router.post('/calculateenglish', async (req, res) => {
  try {
    const { TankID, OpeningFuelFT, OpeningFuelInch, OpeningFuel16, OpeningWaterFT, OpeningWaterInch, OpeningWater16, OpeningTemperature, OpeningDensity, ClosingFuelFT, ClosingFuelInch, ClosingFuel16, ClosingWaterFT, ClosingWaterInch, ClosingWater16, ClosingTemperature, ClosingDensity } = req.body;

// Call the stored procedure using Sequelize's query method
const result = await sequelize.query('CALL SP_CalculatorOpeningClosingEnglish(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', {
  replacements: [
    TankID,
    OpeningFuelFT,
    OpeningFuelInch,
    OpeningFuel16,
    OpeningWaterFT,
    OpeningWaterInch,
    OpeningWater16,
    OpeningTemperature,
    OpeningDensity,
    ClosingFuelFT,
    ClosingFuelInch,
    ClosingFuel16,
    ClosingWaterFT,
    ClosingWaterInch,
    ClosingWater16,
    ClosingTemperature,
    ClosingDensity
  ],
    type: sequelize.QueryTypes.SELECT, // Use SELECT to return results
    raw: true,
    });
    //console.log(result);
    return res.json(result);
  } catch (error) {
    console.error('Error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;