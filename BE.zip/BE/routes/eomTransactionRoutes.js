const express = require("express");
const router = express.Router();
const { sequelize } = require("../models"); // Adjust the path accordingly
const { EOMTransaction } = require("../models");

// POST API to create a new tanker receipt
router.post("/saveEOMTransaction", async (req, res) => {
  const {
    EOMTID,
    SessionID,
    TankID,
    CalibType,
    ProductID,
    Transaction,
    GTicketNum,
    ClientNames,
    Volumes,
    TotalVolume,
    EOMGaugeDateTime,
    RegaugeDateTime,
    EOMGaugeProductFT,
    RegaugeProductFT,
    EOMGaugeProductInch,
    RegaugeProductInch,
    EOMGaugeProduct16,
    RegaugeProduct16,
    EOMGaugeWaterFT,
    RegaugeWaterFT,
    EOMGaugeWaterInch,
    RegaugeWaterInch,
    EOMGaugeWater16,
    RegaugeWater16,
    EOMGaugeProductMetric,
    RegaugeProductMetric,
    EOMGaugeWaterMetric,
    RegaugeWaterMetric,
    EOMGaugeTemperature,
    RegaugeTemperature,
    EOMGaugeDensity15oC,
    RegaugeDensity15oC,
    Status,
    Attachments,
    WithDenaturing,
    VolumeAtAir,
    VolumeAt60,
    SubmitCount,
  } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_SaveEOMTransaction(:EOMTID, :SessionID, :CalibType, :TankID, :ProductID, :Transaction, :GTicketNum, :ClientNames, :Volumes, :TotalVolume, :EOMGaugeDateTime, :RegaugeDateTime, :EOMGaugeProductFT, :RegaugeProductFT, :EOMGaugeProductInch, :RegaugeProductInch, :EOMGaugeProduct16,:RegaugeProduct16, :EOMGaugeWaterFT, :RegaugeWaterFT, :EOMGaugeWaterInch, :RegaugeWaterInch, :EOMGaugeWater16, :RegaugeWater16, :EOMGaugeProductMetric, :RegaugeProductMetric, :EOMGaugeWaterMetric, :RegaugeWaterMetric, :EOMGaugeTemperature, :RegaugeTemperature, :EOMGaugeDensity15oC, :RegaugeDensity15oC, :Status, :Attachments, :WithDenaturing, :VolumeAtAir, :VolumeAt60, :SubmitCount)",
      {
        replacements: {
          EOMTID,
          SessionID,
          TankID,
          CalibType,
          ProductID, 
          Transaction,
          GTicketNum,   
          ClientNames,    
          Volumes,         
          TotalVolume,
          EOMGaugeDateTime,
          RegaugeDateTime,
          EOMGaugeProductFT,
          RegaugeProductFT,
          EOMGaugeProductInch,
          RegaugeProductInch,
          EOMGaugeProduct16,
          RegaugeProduct16,
          EOMGaugeWaterFT,
          RegaugeWaterFT,
          EOMGaugeWaterInch,
          RegaugeWaterInch,
          EOMGaugeWater16,
          RegaugeWater16,
          EOMGaugeProductMetric,
          RegaugeProductMetric,
          EOMGaugeWaterMetric,
          RegaugeWaterMetric,
          EOMGaugeTemperature,
          RegaugeTemperature,
          EOMGaugeDensity15oC,
          RegaugeDensity15oC,
          Status,
          Attachments,
          WithDenaturing,
          VolumeAtAir,
          VolumeAt60,
          SubmitCount,
        },
      }
    );

    return res.json(result);
  } catch (error) {
    console.error("Failed to create end of the month record:", error);
    res.status(500).json({ error: "Failed to create end of the month record" });
  }
});

router.post("/getEOMTransactionRecord", async (req, res) => {
  const { SessionID } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_GetEOMTransactionRecord(:SessionID)",
      {
        replacements: {
          SessionID,
        },
      }
    );
    res.json(result);
  } catch (error) {
    console.error("Error fetching SP_GetEOMTransactionRecord:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/getEOMTransactionNextSessionID", async (req, res) => {
  try {
    const result = await sequelize.query("CALL SP_GetEOMTransactionNextSessionID()");
    res.json(result);
  } catch (error) {
    console.error("Error fetching getEOMTransactionNextSessionID:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
