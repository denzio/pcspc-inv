// routes/calibrationListT4Routes.js
const express = require("express");
const router = express.Router();
const { sequelize } = require("../models"); // Adjust the path accordingly
const { Client } = require("../models");

router.get("/", async (req, res) => {
  try {
    const tankDetails = await sequelize.query("CALL SP_GetClientDetails()");
    res.json(tankDetails);
  } catch (error) {
    console.error("Error fetching Client details:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/add", (req, res) => {
  console.log(res.body);
  const newClientData = req.body;

  Client.create(newClientData)
    .then((data) => {
      res.status(201).json(data);
      console.log("New client has been added");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("New Client not added due to :", error);
    });
});

// PUT route to update a specific client by ID
router.put("/:id", (req, res) => {
  const clientId = req.params.id;
  const updatedClientData = req.body;

  Client.update(updatedClientData, {
    where: { ClientID: clientId },
  })
    .then(() => {
      res.sendStatus(200); // Respond with success status
      console.log("Client updated successfully");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("Error updating client:", error);
    });
});

router.patch("/:id/status", (req, res) => {
  const clientId = req.params.id;
  const newStatus = req.body.status;

  Client.update(
    { Status: newStatus },
    {
      where: { ClientID: clientId },
    }
  )
    .then((data) => {
      res.sendStatus(200); // Respond with success status
      console.log("Client status updated successfully");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("Error updating client status:", error);
    });
});

// DELETE route to delete a specific Client site by ID
router.delete("/:id", (req, res) => {
  const clientID = req.params.id;

  Client.destroy({
    where: { ClientID: clientID },
  })
    .then(() => {
      res.sendStatus(204); // Respond with no content (success)
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
    });
});

router.post("/AmendContract", async (req, res) => {
  const { CTPID, Volume, ContractStartDate, ContractEndDate } = req.body;

  try {
    // Execute the stored procedure
    const result = await sequelize.query(
      "CALL SP_AmendContract(:CTPID, :Volume, :ContractStartDate, :ContractEndDate)",
      {
        replacements: {
          CTPID,
          Volume,
          ContractStartDate,
          ContractEndDate,
        },
      }
    );

    res.json(result);
  } catch (error) {
    console.error("Error Amending Contracs:", error);
    res.status(500).send("Error Amending Contracs:");
  }
});

router.post("/ProductSummaryByClient", async (req, res) => {
  const { ClientID } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_GetProductSummaryByClient(:ClientID)",
      {
        replacements: {
          ClientID,
        },
      }
    );

    return res.json(result);
  } catch (error) {
    console.error("Error Getting ProductSummary of By Client :", error);
    res.status(500).send("Error Getting ProductSummary of By Client .");
  }
});
module.exports = router;
