// routes/calibrationListT4Routes.js
const express = require("express");
const router = express.Router();
const { Role } = require("../models");
const { sequelize } = require("../models"); // Adjust the path accordingly

// Get Role
router.get("/", async (req, res) => {
  try {
    const roleDetails = await sequelize.query("CALL SP_GetRoleDetails()");
    res.json(roleDetails);
  } catch (error) {
    console.error("Error Role details:", error);
    res.status(500).json({ error: "Error Role details:" });
  }
});

// New Role
router.post("/add", (req, res) => {
  const newRole = req.body;

  Role.create(newRole)
    .then((data) => {
      res.status(201).json(data);
      console.log("New Role has been added");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("New Role has been added :", error);
    });
});

// Get Role by id
router.post("/:id", (req, res) => {
  const userRoleID = req.params.id;

  Role.findOne(
    { where: { UserRoleID: userRoleID } })
    .then((data) => {
      res.json(data); // This will send the data as a JSON response
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
    });
});

// Edit Role
router.put("/:id", (req, res) => {
  const userRoleID = req.params.id;
  const updatedRoleData = req.body;

  Role.update(updatedRoleData, {
    where: { UserRoleID: userRoleID },
  })
    .then(() => {
      res.sendStatus(200); // Respond with success status
      console.log("Role has been updated");
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
      console.error("Error updating Role:", error);
    });
});

// Change Status
router.patch("/:id/status", async (req, res) => {
  const roleId = req.params.id;
  const newStatus = req.body.status;

  try {
    const UserRoleDetails = await sequelize.query(
      "CALL SP_UpdateRoleDetails(:roleId, :newStatus)",
      {
        replacements: {
          roleId,
          newStatus,
        },
      }
    );
    res.json(UserRoleDetails);
  } catch (error) {
    console.error("Error fetching Role details:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Delete Role
router.delete("/:id", (req, res) => {
  const userRoleID = req.params.id;

  Role.destroy({
    where: { UserRoleID: userRoleID },
  })
    .then(() => {
      res.sendStatus(204); // Respond with no content (success)
    })
    .catch((error) => {
      res.status(500).send("Error: " + error.message);
    });
});

module.exports = router;
