// routes/calibrationListT4Routes.js
const express = require("express");
const router = express.Router();
const { Masterlist } = require("../models");
const { sequelize } = require("../models"); // Adjust the path accordingly

router.get("/", async (req, res) => {
  try {
    // Call the stored procedure using Sequelize's query method
    const result = await sequelize.query("CALL SP_GetMasterlistDetails()");
    return res.json(result);
  } catch (error) {
    console.error("Error:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/GetTankContracts", async (req, res) => {
  const { TankID, ContractType } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_GetContracts(:TankID, :ContractType)",
      {
        replacements: {
          TankID,
          ContractType,
        },
      }
    );

    return res.json(result);
  } catch (error) {
    console.error("Error Getting Company Name(s):", error);
    res.status(500).send("Error Getting Company Name(s).");
  }
});

router.post("/EndContract", async (req, res) => {
  const { CTPID } = req.body;
  try {
    const result = await sequelize.query("CALL SP_EndContract(:CTPID)", {
      replacements: {
        CTPID,
      },
    });

    return res.json(result);
  } catch (error) {
    console.error("Error on End Contract:", error);
    res.status(500).send("Error on End Contract.");
  }
});

router.post("/DeleteTank", async (req, res) => {
  const { TankID, ContractType, ProductID } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_DecommissionTank(:TankID, :ContractType, :ProductID)",
      {
        replacements: {
          TankID,
          ContractType,
          ProductID,
        },
      }
    );

    return res.json(result);
  } catch (error) {
    console.error("Error on DecommissionTank:", error);
    res.status(500).send("Error on DecommissionTank.");
  }
});

router.post("/ReusedTank", async (req, res) => {
  const {
    TankID,
    ProductID,
    ContractType,
    OriginalContract,
    OriginalProductID,
  } = req.body;
  try {
    const result = await sequelize.query(
      "CALL SP_ReusedTank(:TankID, :ProductID, :ContractType, :OriginalContract, :OriginalProductID)",
      {
        replacements: {
          TankID,
          ProductID,
          ContractType,
          OriginalContract,
          OriginalProductID,
        },
      }
    );
    return res.json(result);
  } catch (error) {
    console.error("Error on ReusedTank:", error);
    res.status(500).send("Error on ReusedTank.");
  }
});
module.exports = router;
