// hardcoded-upload.js
const fs = require('fs');
const AWS = require('aws-sdk');

// Configure AWS SDK
AWS.config.update({
    accessKeyId: 'AKIAYWDI2CNZX4QP7WE4',
    secretAccessKey: '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',
    region: 'us-east-1'
});

const s3 = new AWS.S3();
const bucketName = 'pcuploadattachments';
const keyName = `test-file-${Date.now()}.txt`;
const filePath = './test-file.txt';

// Read the file content
const fileContent = fs.readFileSync(filePath);

// Set up the parameters for the upload
const params = {
    Bucket: bucketName,
    Key: keyName,
    Body: fileContent
};

// Upload to S3
s3.upload(params, (err, data) => {
    if (err) {
        console.error('Error uploading file:', err);
    } else {
        console.log('Successfully uploaded file to:', data.Location);
    }
});
