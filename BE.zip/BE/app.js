const express = require("express");
const cors = require("cors"); // Import CORS module
const bodyParser = require("body-parser");
const mssql = require("mssql");
const {
  sequelize,
  CalculatorEnglish,
  CalculatorMetric,
  CalibrationListT4,
} = require("./models"); // Import from the models index
const calculatorEnglishRoutes = require("./routes/calculatorEnglishRoutes"); // Adjust the path accordingly
const calculatorMetricRoutes = require("./routes/calculatorMetricRoutes"); // Adjust the path accordingly
const calibrationListT4Routes = require("./routes/calibrationListT4Routes"); // Adjust the path accordingly
const clientRoutes = require("./routes/clientRoutes"); // Adjust the path accordingly
const tankRoutes = require("./routes/tankRoutes"); // Adjust the path accordingly
const productRoutes = require("./routes/productRoutes"); // Adjust the path accordingly
const siteRoutes = require("./routes/siteRoutes"); // Adjust the path accordingly
const loadingRackRoutes = require("./routes/loadingRackRoutes"); // Adjust the path accordingly
const employeeRoutes = require("./routes/employeeRoutes"); // Adjust the path accordingly
const userRoutes = require("./routes/userRoutes"); // Adjust the path accordingly
const roleRoutes = require("./routes/roleRoutes"); // Adjust the path accordingly
const ctpRoutes = require("./routes/ctpRoutes"); // Adjust the path accordingly
const ctpTransactionRoutes = require("./routes/ctpTransactionRoutes"); // Adjust the path accordingly
const calibrationEnglish = require("./routes/CalibrationEnglish");
const CalibrationMetric = require("./routes/CalibrationMetric");
const masterlistRoutes = require("./routes/masterlistRoutes"); // Adjust the path accordingly
const tankHistoryRoutes = require("./routes/tankHistoryRoutes"); // Adjust the path accordingly
const omtlRoutes = require("./routes/OMTL");
const tankerReceiptsRoutes = require("./routes/tankerReceiptsRoutes"); // Adjust the path accordingly
const uploadAttachmentsRoutes = require("./routes/uploadAttachmentsRoutes"); // Adjust the path as necessary
const VesselLoadingRoutes = require("./routes/VesselLoadingRoutes"); // Adjust the path as necessary
const VesselBunkeringRoute = require("./routes/VesselBunkeringRoute"); // Adjust the path as necessary
const InterTankRoute = require("./routes/InterTankRoute"); // Adjust the path as necessary
const CubiTransferRoute = require("./routes/CubiTransferRoute"); // Adjust the path as necessary
const ConsolidationRoute = require("./routes/ConsolidationRoute"); // Adjust the path as necessary
const TruckReceiptsRoutes = require("./routes/TruckReceiptsRoutes"); // Adjust the path as necessary
const eomTransactionRoutes = require("./routes/eomTransactionRoutes"); // Adjust the path accordingly
const tankTruckIssuanceRoutes = require("./routes/tankTruckIssuanceRoutes"); // Adjust the path accordingly
const LedgerRoutes = require("./routes/LedgerRoutes"); // Adjust the path accordingly
const app = express();

var http = require("http");
var fs = require("fs"); // to get data from html file

// Enable CORS for all routes and origins
app.use(cors());

// Middleware
app.use(express.json({ limit: "100mb" }));

// Routes
// Define your routes here
app.use("/api/calculations", calculatorEnglishRoutes); //temporary location
app.use("/api/calculations", calculatorMetricRoutes); //temporary location
app.use("/api/calibrationListT4", calibrationListT4Routes);
app.use("/api/client", clientRoutes);
app.use("/api/tank", tankRoutes);
app.use("/api/product", productRoutes);
app.use("/api/site", siteRoutes);
app.use("/api/loadingrack", loadingRackRoutes);
app.use("/api/employee", employeeRoutes);
app.use("/api/user", userRoutes);
app.use("/api/role", roleRoutes);
app.use("/api/ctp", ctpRoutes);
app.use("/api/ctpTransaction", ctpTransactionRoutes);
app.use("/api/calibrationEnglish", calibrationEnglish);
app.use("/api/calibrationMetric", CalibrationMetric);
app.use("/api/masterlist", masterlistRoutes);
app.use("/api/tankhist", tankHistoryRoutes);
app.use("/api/omtl", omtlRoutes);
app.use("/api/tankerReceipts", tankerReceiptsRoutes);
app.use("/api/VesselLoading", VesselLoadingRoutes);
app.use("/api/uploadAttachments", uploadAttachmentsRoutes);
app.use("/api/VesselBunkeringRoute", VesselBunkeringRoute);
app.use("/api/InterTankRoute", InterTankRoute);
app.use("/api/CubiTransferRoute", CubiTransferRoute);
app.use("/api/ConsolidationRoute", ConsolidationRoute);
app.use("/api/TruckReceiptsRoutes", TruckReceiptsRoutes);
app.use("/api/eomTransactionRoutes", eomTransactionRoutes);
app.use("/api/tankTruckIssuanceRoutes", tankTruckIssuanceRoutes);
app.use("/api/LedgerRoutes", LedgerRoutes);
// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send("Something went wrong!");
});
app.get("/", (req, res) => {
  res.send("Hello World!");
});
// Start the server
const PORT = 3006;
const os = require("os");
console.log(`Server is running on http://${os.hostname()}`);

sequelize
  .sync({ force: false }) // Set force to true to drop and recreate tables on every app start
  .then(() => {
    app.listen(PORT, () => {
      // Use os.hostname() to get the server's hostname
      console.log(`Server is running on http://${os.hostname()}:${PORT}`);
    });
  })
  .catch((error) => {
    console.error("Error syncing database:", error);
  });
