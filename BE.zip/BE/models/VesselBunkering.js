const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class VesselBunkering extends Model {}

module.exports = (sequelize) => {
  VesselBunkering.init(
    {},
    {
      sequelize, // Pass the connection instance
      modelName: "VesselBunkering", // Model name
      tableName: "VesselBunkering", // Explicitly specify the table name
      freezeTableName: true, // Prevent Sequelize from pluralizing the table name
      timestamps: false, // Disable automatic timestamp fields
    }
  );

  return VesselBunkering;
};
