const Sequelize = require("sequelize");

// Initialize Sequelize with your database configuration
const sequelize = new Sequelize({
  dialect: "mysql", // Change dialect to 'mysql'
  host: "database-1.c1ymq60io07n.us-east-1.rds.amazonaws.com", // MySQL server host (assuming it's running on localhost)
  port: 3306, // Default MySQL port
  username: "admin", // Your MySQL username
  password: "L3tm31n123!", // Your MySQL password
  database: "duwltnjc_dbdev", // Name of your MySQL database
});

module.exports = { sequelize };
// Import models
const CalculatorEnglish = require("./CalculatorEnglish")(
  sequelize,
  Sequelize.DataTypes
);
const CalculatorMetric = require("./CalculatorMetric")(
  sequelize,
  Sequelize.DataTypes
);
const CalibrationListT4 = require("./CalibrationListT4")(
  sequelize,
  Sequelize.DataTypes
);
const Client = require("./Client")(sequelize, Sequelize.DataTypes);
const Tank = require("./Tank")(sequelize, Sequelize.DataTypes);
const Product = require("./Product")(sequelize, Sequelize.DataTypes);
const Site = require("./Site")(sequelize, Sequelize.DataTypes);
const LoadingRack = require("./LoadingRack")(sequelize, Sequelize.DataTypes);
const Employee = require("./Employee")(sequelize, Sequelize.DataTypes);
const User = require("./User")(sequelize, Sequelize.DataTypes);
const Role = require("./Role")(sequelize, Sequelize.DataTypes);
const CTP = require("./CTP")(sequelize, Sequelize.DataTypes);
const CTPTransaction = require("./CTPTransaction")(sequelize,Sequelize.DataTypes);
const CalibrationEnglish = require("./CalibrationEnglish")(sequelize,Sequelize.DataTypes);
const CalibrationMetric = require("./CalibrationMetric")(sequelize,Sequelize.DataTypes);
const Masterlist = require("./Masterlist")(sequelize, Sequelize.DataTypes);
const TankHistory = require("./TankHistory")(sequelize, Sequelize.DataTypes);
const OMTLMetric = require("./OMTLMetric")(sequelize, Sequelize.DataTypes);
const UserActivityLog = require("./UserActivityLog")(sequelize, Sequelize.DataTypes);
const TankerReceipts = require("./TankerReceipts")(sequelize, Sequelize.DataTypes);
const EOMTransaction = require("./EOMTransaction")(sequelize, Sequelize.DataTypes);
const TankTruckIssuance = require("./TankTruckIssuance")(sequelize, Sequelize.DataTypes);
// Define associations here if any
// Example: CalculatorEnglish.hasMany(OtherModel);

// Export the sequelize instance and models
module.exports = {
  sequelize,
  CalculatorEnglish,
  CalculatorMetric,
  CalibrationListT4,
  Client,
  Tank,
  Product,
  Employee,
  User,
  Role,
  CTP,
  CTPTransaction,
  Site,
  LoadingRack,
  CalibrationEnglish,
  CalibrationMetric,
  Masterlist,
  TankHistory,
  OMTLMetric,
  UserActivityLog,
  TankerReceipts,
  EOMTransaction,
  TankTruckIssuance
};
