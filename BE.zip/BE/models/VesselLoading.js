const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class VesselLoading extends Model {}

module.exports = (sequelize) => {
  VesselLoading.init(
    {},
    {
      sequelize, // Pass the connection instance
      modelName: "VesselLoading", // Model name
      tableName: "VesselLoading", // Explicitly specify the table name
      freezeTableName: true, // Prevent Sequelize from pluralizing the table name
      timestamps: false, // Disable automatic timestamp fields
    }
  );

  return VesselLoading;
};
