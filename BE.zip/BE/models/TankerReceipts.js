const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class TankerReceipts extends Model {}

module.exports = (sequelize) => {
  TankerReceipts.init(
    {
      // Model attributes are defined here
      TRID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true
      },
      TankID: {
        type: DataTypes.STRING,
        allowNull: false
      },
      Product: {
        type: DataTypes.STRING,
        allowNull: false
      },
      Transaction: {
        type: DataTypes.STRING,
        allowNull: false
      },
      ClientNo: {
        type: DataTypes.STRING,
        allowNull: false
      },
      ClientNames: {
        type: DataTypes.STRING,
        allowNull: false
      },
      VesselName: {
        type: DataTypes.STRING,
        allowNull: false
      },
      OpeningDateTime: {
        type: DataTypes.DATE,
        allowNull: false
      },
      ClosingDateTime: {
        type: DataTypes.DATE,
        allowNull: false
      },
      OpeningProductFT: {
        type: DataTypes.STRING,
        allowNull: false
      },
      ClosingProductFT: {
        type: DataTypes.STRING,
        allowNull: false
      },
      OpeningWaterInch: {
        type: DataTypes.STRING,
        allowNull: false
      },
      ClosingWaterInch: {
        type: DataTypes.STRING,
        allowNull: false
      },
      OpeningTemperature: {
        type: DataTypes.STRING,
        allowNull: false
      },
      ClosingTemperature: {
        type: DataTypes.STRING,
        allowNull: false
      },
      OpeningDensity15oC: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
      },
      ClosingDensity15oC: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
      },
      Status: {
        type: DataTypes.STRING,
        allowNull: false
      },
      Remarks: {
        type: DataTypes.STRING,
        allowNull: false
      }
    },
    {
      sequelize, // Pass the connection instance
      modelName: "TankerReceipts", // Model name
      tableName: "TankerReceipts", // Explicitly specify the table name
      freezeTableName: true, // Prevent Sequelize from pluralizing the table name
      timestamps: false, // Disable automatic timestamp fields
    }
  );

  return TankerReceipts;
};
