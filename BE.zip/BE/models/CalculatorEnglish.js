const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class CalculatorEnglish extends Model {}

module.exports = (sequelize) => {
  CalculatorEnglish.init(
    {
      // Model attributes are defined here
      TankID: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      OpeningFuelFT: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      // Add other input parameters as needed
      OpeningFuelInch: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      OpeningFuel16: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      OpeningWaterFT: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      OpeningWaterInch: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      OpeningWater16: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      OpeningTemperature: {
        type: DataTypes.DECIMAL,
        allowNull: false,
      },
      OpeningDensity: {
        type: DataTypes.DECIMAL,
        allowNull: false,
      },
      ClosingFuelFT: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      ClosingFuelInch: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      ClosingFuel16: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      ClosingWaterFT: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      ClosingWaterInch: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      ClosingWater16: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      ClosingTemperature: {
        type: DataTypes.DECIMAL,
        allowNull: false,
      },
      ClosingDensity: {
        type: DataTypes.DECIMAL,
        allowNull: false,
      },
      // ... other attributes ...
    },
    {
      sequelize, // Pass the connection instance
      modelName: "CalculatorEnglish", // Model name
    }
  );

  return CalculatorEnglish;
};
