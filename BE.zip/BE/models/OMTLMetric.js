const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class OMTLMetric extends Model {}

module.exports = (sequelize) => {
OMTLMetric.init(
    {
        OMTLID: {
            type: DataTypes.INTEGER,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true
        },
        TankID: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        ProductID: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        ClientID: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        TransactionType: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        DateTimeOpening: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        DateTimeClosing: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        GaugeFuelWaterOpening: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        GaugeFuelWaterClosing: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        GaugeWaterOpening: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        GaugeWaterClosing: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        AveTemperatureOpening: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        AveTemperatureClosing: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        DensityOpening: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        DensityClosing: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        CorrectionFactorVolOpening: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        CorrectionFactorVolClosing: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        TotalObservedVolOpening: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        TotalObservedVolClosing: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        FreeWaterVolOpening: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        FreeWaterVolClosing: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        GrossObservedVolOpening: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        GrossObservedVolClosing: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        GrossStdVolOpening: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        GrossStdVolClosing: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        NetStdVolOpening: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        NetStdVolClosing: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        WCFOpening: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        WCFClosing: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        MetricTonsOpening: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        MetricTonsClosing: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        LongTonsOpening: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        LongTonsClosing: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        Status: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        Memo: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        USBbls: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        LitersMetricTons: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        LongTons: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        USBblsObsTemp: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        LitersObsTemp: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        HasClosing: {
            type: DataTypes.TINYINT,
            allowNull: false,
        },
        DateCreated: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        TankNumber: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        SessionID: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        TransType: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        Transaction: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        Remarks: {
            type: DataTypes.STRING,
            allowNull: false,
        },
    },
    {
      sequelize, // Pass the connection instance
      modelName: "OMTLMetric", // Model name
      tableName: "OMTLMetric", // Explicitly specify the table name
      freezeTableName: true, // Prevent Sequelize from pluralizing the table name
      timestamps: false,
    }
);

  return OMTLMetric;
};
