const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class TruckReceipts extends Model {}

module.exports = (sequelize) => {
  TruckReceipts.init(
    {},
    {
      sequelize, // Pass the connection instance
      modelName: "TruckReceipts", // Model name
      tableName: "TruckReceipts", // Explicitly specify the table name
      freezeTableName: true, // Prevent Sequelize from pluralizing the table name
      timestamps: false, // Disable automatic timestamp fields
    }
  );

  return TruckReceipts;
};
