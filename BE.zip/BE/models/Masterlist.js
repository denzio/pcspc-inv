const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class Masterlist extends Model {}

module.exports = (sequelize) => {
  Masterlist.init(
    {
      // Model attributes are defined here
      CTPID: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      TankID: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      ProductID: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      ClientID: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      ContractType: {
        type: DataTypes.STRING,
        allowNull: true,
      },
    },
    {
      sequelize, // Pass the connection instance
      modelName: "CTP", // Model name
      tableName: "CTP", // Explicitly specify the table name
      freezeTableName: true, // Prevent Sequelize from pluralizing the table name
      timestamps: false,
    }
  );
  Masterlist.removeAttribute("id");
  return Masterlist;
};
