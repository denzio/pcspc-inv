const { Model, DataTypes } = require('sequelize');
const { sequelize } = require('../config/database'); // Adjust the path as necessary

class Client extends Model {}

module.exports = (sequelize) => {
  Client.init({
    // Model attributes are defined here
    ClientID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      autoIncrement: true,
      primaryKey: true
    },
    CompanyName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    // Add other input parameters as needed
    Email: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    PhoneNumber: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    Address: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    Country: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    Status: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  }, {
    sequelize, // Pass the connection instance
    modelName: 'Client', // Model name
    tableName: 'Client', // Explicitly specify the table name
    freezeTableName: true, // Prevent Sequelize from pluralizing the table name
    timestamps: false,
  });

  return Client;
};