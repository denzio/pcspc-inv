const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class CalibrationEnglish extends Model {}

module.exports = (sequelize) => {
  CalibrationEnglish.init(
    {
      // Model attributes are defined here
      EmployeeID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: false,
      },
      TankID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: false,
      },
      FT: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: false,
      },
      INCH: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: false,
      },
      16: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: false,
      },
      Fuel: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: true,
      },
      Water: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: true,
      },
      CalibrationDate: {
        type: DataTypes.DATE,
        allowNull: false,
      },
    },
    {
      sequelize, // Pass the connection instance
      modelName: "CalibrationEnglish", // Model name
      tableName: "CalibrationEnglish", // Explicitly specify the table name
      freezeTableName: true, // Prevent Sequelize from pluralizing the table name
      timestamps: false,
      createdAt: false,
      updatedAt: false,
      primaryKey: false,
    }
  );
  CalibrationEnglish.removeAttribute("id");
  return CalibrationEnglish;
};
