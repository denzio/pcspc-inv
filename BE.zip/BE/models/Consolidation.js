const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class Consolidation extends Model {}

module.exports = (sequelize) => {
  Consolidation.init(
    {},
    {
      sequelize, // Pass the connection instance
      modelName: "Consolidation", // Model name
      tableName: "Consolidation", // Explicitly specify the table name
      freezeTableName: true, // Prevent Sequelize from pluralizing the table name
      timestamps: false, // Disable automatic timestamp fields
    }
  );

  return Consolidation;
};
