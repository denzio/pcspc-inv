const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class Role extends Model {}

module.exports = (sequelize) => {
  Role.init(
    {
      // Model attributes are defined here
      UserRoleID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      RoleName: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      Status: {
        type: DataTypes.TINYINT,
        allowNull: false,
      },
      DBView: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      TranCreate: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      TranEdit: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      TranApprove: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      TranView: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      InvView: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      RepGenerate: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      RepView: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      TankAddDel: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      TankView: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      ClientAddDel: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      ClientView: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      FuelAddDel: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      FuelView: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      UserManage: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      EditOnce: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      SiteID: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
    },
    {
      sequelize, // Pass the connection instance
      modelName: "Role", // Model name
      tableName: "UserRole", // Explicitly specify the table name
      freezeTableName: true, // Prevent Sequelize from pluralizing the table name
      timestamps: false,
    }
  );

  return Role;
};
