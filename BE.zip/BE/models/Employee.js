const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class Employee extends Model {}

module.exports = (sequelize) => {
  Employee.init(
    {
      // Model attributes are defined here
      EmployeeID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      DateOfBirth: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      Gender: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      FirstName: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      LastName: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      Email: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      PhoneNumber: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      Address: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      EmploymentStatus: {
        type: DataTypes.TINYINT,
        allowNull: false,
      },
    },
    {
      sequelize, // Pass the connection instance
      modelName: "Employee", // Model name
      tableName: "Employee", // Explicitly specify the table name
      freezeTableName: true, // Prevent Sequelize from pluralizing the table name
      timestamps: false,
    }
  );

  return Employee;
};
