const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class CTP extends Model {}

module.exports = (sequelize) => {
  CTP.init(
    {
      CTPID: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      // Model attributes are defined here
      ClientID: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      TankID: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      // Add other input parameters as needed
      ProductID: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      ContractType: {
        type: DataTypes.STRING,
        allowNull: true,
      },
    },
    {
      sequelize, // Pass the connection instance
      modelName: "CTP", // Model name
      tableName: "CTP", // Explicitly specify the table name
      freezeTableName: true, // Prevent Sequelize from pluralizing the table name
      timestamps: false,
    }
  );
  CTP.removeAttribute("id");
  return CTP;
};
