const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class CalculatorMetric extends Model {}

module.exports = (sequelize) => {
  CalculatorMetric.init(
    {
      // Model attributes are defined here
      TankID: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      OpeningFuel: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      OpeningWater: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      OpeningTemperature: {
        type: DataTypes.DECIMAL,
        allowNull: false,
      },
      OpeningDensity20: {
        type: DataTypes.DECIMAL,
        allowNull: false,
      },
      OpeningDensity15: {
        type: DataTypes.DECIMAL,
        allowNull: false,
      },
      ClosingFuel: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      ClosingWater: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      ClosingTemperature: {
        type: DataTypes.DECIMAL,
        allowNull: false,
      },
      ClosingDensity20: {
        type: DataTypes.DECIMAL,
        allowNull: false,
      },
      ClosingDensity15: {
        type: DataTypes.DECIMAL,
        allowNull: false,
      },
    },
    {
      sequelize, // Pass the connection instance
      modelName: "CalculatorMetric", // Model name
    }
  );

  return CalculatorMetric;
};
