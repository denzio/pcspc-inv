const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class UserActivityLog extends Model {}

module.exports = (sequelize) => {
  UserActivityLog.init(
    {
      // Model attributes are defined here
      LogID: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        primaryKey: true,
      },
      EmployeeID: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      ActionType: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      ActionDetails: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      ClientIP: {
        type: DataTypes.STRING(45),
        allowNull: false,
      },
      CreatedAt: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
    },
    {
      sequelize, // Pass the connection instance
      modelName: "UserActivityLog", // Model name
      tableName: "UserActivityLog", // Explicitly specify the table name
      freezeTableName: true, // Prevent Sequelize from pluralizing the table name
      timestamps: false,
    }
  );

  return UserActivityLog;
};
