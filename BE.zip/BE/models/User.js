const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class User extends Model {}

module.exports = (sequelize) => {
  User.init(
    {
      // Model attributes are defined here
      UserID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      EmployeeID: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      UserName: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      Password: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      HasAccess: {
        type: DataTypes.TINYINT,
        allowNull: false,
      },
      UserRoleID: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
    },
    {
      sequelize, // Pass the connection instance
      modelName: "User", // Model name
      tableName: "User", // Explicitly specify the table name
      freezeTableName: true, // Prevent Sequelize from pluralizing the table name
      timestamps: false,
    }
  );

  return User;
};
