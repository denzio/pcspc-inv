const { Model, DataTypes } = require('sequelize');
const { sequelize } = require('../config/database'); // Adjust the path as necessary

class LocationSite extends Model {}

module.exports = (sequelize) => {
  LocationSite.init({
    // Model attributes are defined here
    SiteID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      autoIncrement: true,
      primaryKey: true
    },
    SiteName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    // Add other input parameters as needed
    Address: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    Country: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    Status: {
      type: DataTypes.TINYINT,
      allowNull: false,
    },
  }, {
    sequelize, // Pass the connection instance
    modelName: 'LocationSite', // Model name
    tableName: 'LocationSite', // Explicitly specify the table name
    freezeTableName: true, // Prevent Sequelize from pluralizing the table name
    timestamps: false,
  });

  return LocationSite;
};