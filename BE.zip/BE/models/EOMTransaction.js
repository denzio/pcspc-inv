const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class EOMTransaction extends Model {}

module.exports = (sequelize) => {
  EOMTransaction.init(
    {
      // Model attributes are defined here
      EOMTID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true
      },
      TankID: {
        type: DataTypes.STRING,
        allowNull: false
      },
      Product: {
        type: DataTypes.STRING,
        allowNull: false
      },
      Transaction: {
        type: DataTypes.STRING,
        allowNull: false
      },
      ClientNo: {
        type: DataTypes.STRING,
        allowNull: false
      },
      ClientNames: {
        type: DataTypes.STRING,
        allowNull: false
      },
      EOMGaugeDateTime: {
        type: DataTypes.DATE,
        allowNull: false
      },
      EOMGaugeProductFT: {
        type: DataTypes.STRING,
        allowNull: false
      },
      EOMGaugeWaterInch: {
        type: DataTypes.STRING,
        allowNull: false
      },
      EOMGaugeTemperature: {
        type: DataTypes.STRING,
        allowNull: false
      },
      EOMGaugeDensity15oC: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
      },
      Status: {
        type: DataTypes.STRING,
        allowNull: false
      },
      Remarks: {
        type: DataTypes.STRING,
        allowNull: false
      }
    },
    {
      sequelize, // Pass the connection instance
      modelName: "EOMTransaction", // Model name
      tableName: "EOMTransaction", // Explicitly specify the table name
      freezeTableName: true, // Prevent Sequelize from pluralizing the table name
      timestamps: false, // Disable automatic timestamp fields
    }
  );

  return EOMTransaction;
};
