const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class LoadingRack extends Model {}

module.exports = (sequelize) => {
    LoadingRack.init(
    {
      // Model attributes are defined here
      LRID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      LoadingRack: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      SiteID: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
    },
    {
      sequelize, // Pass the connection instance
      modelName: "LoadingRack", // Model name
      tableName: "LoadingRack", // Explicitly specify the table name
      freezeTableName: true, // Prevent Sequelize from pluralizing the table name
      timestamps: false,
    }
  );

  return LoadingRack;
};
