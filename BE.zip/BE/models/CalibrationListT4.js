// models/calibrationListT4.js
const { Model, DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Adjust the path accordingly

class CalibrationListT4 extends Model {}

module.exports = (sequelize) => {
    CalibrationListT4.init({
    // Model attributes are defined here
    API: {
        type: DataTypes.DECIMAL,
      },
      ReferenceValue: {
        type: DataTypes.DECIMAL,
      },

  }, {
    sequelize, // Pass the connection instance
    modelName: 'CalibrationListT4', // Model name
    tableName: 'CalibrationListT4', // Explicitly specify the table name
    freezeTableName: true // Prevent Sequelize from pluralizing the table name
  });

  return CalibrationListT4;
};