const { Model, DataTypes } = require('sequelize');
const { sequelize } = require('../config/database'); // Adjust the path as necessary

class CTPTransaction extends Model {}

module.exports = (sequelize) => {
  CTPTransaction.init({
    // Model attributes are defined here
    CTPID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      autoIncrement: false,
      primaryKey: true
    },
    CTPTID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      autoIncrement: true,
      primaryKey: true
    },
    TankID: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    ClientID: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    // Add other input parameters as needed
    ProductID: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    TankNumber: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    CompanyName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    // Add other input parameters as needed
    ProductName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    Volume: {
      type: DataTypes.DECIMAL,
      allowNull: false,
    },
    ContractStartDate: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    ContractEndDate: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    ContractType: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    Remarks: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize, // Pass the connection instance
    modelName: 'CTPTransaction', // Model name
    tableName: 'CTPTransaction', // Explicitly specify the table name
    freezeTableName: true, // Prevent Sequelize from pluralizing the table name
    timestamps: false,
  });

  return CTPTransaction;
};