const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/database"); // Adjust the path as necessary

class Tank extends Model {}

module.exports = (sequelize) => {
  Tank.init(
    {
      // Model attributes are defined here
      TankID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      TankNumber: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      // Add other input parameters as needed
      CalibType: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      ShellCapacity_BBLS: {
        type: DataTypes.DECIMAL,
        allowNull: false,
      },
      InstallationDate: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      SiteID: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      TankHeight_FT: {
        type: DataTypes.DECIMAL,
        allowNull: false,
      },
      TankDiameter_FT: {
        type: DataTypes.DECIMAL,
        allowNull: false,
      },
      SafeFill_BBLS: {
        type: DataTypes.DECIMAL,
        allowNull: false,
      },
      CalibrationDate: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      MaintenanceSchedule: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      Status: {
        type: DataTypes.TINYINT,
        allowNull: false,
      },
      Memo: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      UllageCapacity: {
        type: DataTypes.DECIMAL,
        allowNull: false,
      },
      DeadstockVolume_BBLS: {
        type: DataTypes.DECIMAL,
        allowNull: false,
      },
      MaximumCapacity: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      WithCenterTable: {
        type: DataTypes.TINYINT,
        allowNull: false,
      },
      ReferenceHeight_Center: {
        type: DataTypes.DECIMAL,
        allowNull: true,
      },
      ReferenceHeight_Side: {
        type: DataTypes.DECIMAL,
        allowNull: true,
      },
    },
    {
      sequelize, // Pass the connection instance
      modelName: "Tank", // Model name
      tableName: "Tank", // Explicitly specify the table name
      freezeTableName: true, // Prevent Sequelize from pluralizing the table name
      timestamps: false,
    }
  );

  return Tank;
};
