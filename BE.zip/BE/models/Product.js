const { Model, DataTypes } = require('sequelize');
const { sequelize } = require('../config/database'); // Adjust the path as necessary

class Product extends Model {}

module.exports = (sequelize) => {
  Product.init({
    // Model attributes are defined here
    ProductID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      autoIncrement: true,
      primaryKey: true
    },
    ProductName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    // Add other input parameters as needed
    Description: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    Status: {
      type: DataTypes.TINYINT,
      allowNull: false,
    },
  }, {
    sequelize, // Pass the connection instance
    modelName: 'Product', // Model name
    tableName: 'Product', // Explicitly specify the table name
    freezeTableName: true, // Prevent Sequelize from pluralizing the table name
    timestamps: false,
  });

  return Product;
};