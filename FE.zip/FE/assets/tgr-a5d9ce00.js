import{j as r}from"./index-10a53317.js";import{B as o}from"./Breadcrumb-8b0d4dbc.js";const s=()=>r.jsxs(r.Fragment,{children:[r.jsx(o,{pageName:"TGR"}),"Coming Soon..."]});export{s as default};
