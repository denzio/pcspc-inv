import{j as o}from"./index-10a53317.js";const n=()=>o.jsx("h1",{children:"Fuel Page Coming soon..."});export{n as default};
