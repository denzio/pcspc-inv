var E=(r=>(r.ENGLISH="ENGLISH",r.METRIC="METRIC",r))(E||{});export{E as O};
